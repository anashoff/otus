<html>
 <meta http-equiv="refresh" content="300">

<?php

// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");








// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select name from lab";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
echo "<table border='1px'>\n";
echo "\t<tr>\n";
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {

#    foreach ($line as $col_value) {
        echo "\t\t<td><a href='?lab=$line[0]'>$line[0]</a></td>\n";
#    }
}
echo "<td><a href='?lab=СХРМИ&room=ХР-134'>ХР-134</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-218'>ХР-218</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-219'>ХР-219</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-220'>ХР-220</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-221'>ХР-221</td>";
    echo "\t</tr>\n";

echo "</table>\n";

// Очистка результата
pg_free_result($result);




$getlab = $_REQUEST['lab'];
$getroom = $_REQUEST['room'];

#echo $lab;
preg_match ("/[a-zA-Zа-яА-Я]+/msiu",$getlab,$matches);
#print_r ($matches);
$lab = $matches[0];

preg_match ("/[a-zA-Zа-яА-Я-0-9]+/msiu",$getroom,$matches);
#print_r ($matches);
$room = $matches[0];

if (strlen($room)>0) 
$qroom = " and sample.aliquot_group like '".$room."%' ";
else
$qroom="";

#exit(0);

if (strlen($lab)>0) {
#1
echo "<table border='1px'>\n";
#echo "<tr><td  style='vertical-align:top'>\n";


##############################
#2
#####################################
#echo "<table style='border-spacing: 5px '>\n";
echo "<tr><th colspan='9'>Показатели в работе</th></tr>\n\n";
echo "<tr><th>№</th>
<th>Показатель</th>
<th>>8 дней</th>
<th> 6-8 дней</th>
<th><6 дней</th>
<th> Всего </th>
<th>пробы >8</th>
<th>пробы 6-8 дней</th>
<th>пробы <6 дней</th>

<tr>
";
#echo "<tr><td>";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab'";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 


$query = "select result.name, count(result.name)--,project.*,analysis
from result 
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number = result.sample_number
inner join project on project.name = sample.project
where sample.status not in  ('A','X') and result.status not in  ('A','X') 
and result.reportable= 'T' and result.displayed = 'T' and result.c_metodic_code is not null
and sample.c_protocol_number is not null and project.closed='F'
and project.date_created > now() - interval '2 month'
 and project.customer <> 'TEST_EXAMPLE' ".$qroom."
and test.lab='$lab'
group by result.name
order by result.name";

$query = "select result.name,
sum(case when sample.login_date < add_workdays(now()::timestamp,-8) then 1 else 0 end ) as red,
sum(case when sample.login_date < add_workdays(now()::timestamp,-6) and sample.login_date > add_workdays(now()::timestamp,-8) then 1 else 0 end ) as yellow,
sum(case when sample.login_date > add_workdays(now()::timestamp,-6) then 1 else 0 end ) as green,
string_agg(case when sample.login_date < add_workdays(now()::timestamp,-8) then 
    '<a target=\"_blank\" href=http://192.168.50.250/queue/lims.php?read=' || sample.c_protocol_number || '>' || sample.c_protocol_number || '</a>' else '' end,' ' order by sample.c_protocol_number) as pro,

string_agg(case when sample.login_date < add_workdays(now()::timestamp,-6) and sample.login_date > add_workdays(now()::timestamp,-8) then 
    '<a target=\"_blank\" href=http://192.168.50.250/queue/lims.php?read=' || sample.c_protocol_number || '>' || sample.c_protocol_number || '</a>' else '' end,' ' order by sample.c_protocol_number) as pro2,

string_agg(case when sample.login_date > add_workdays(now()::timestamp,-6) then 
    '<a target=\"_blank\" href=http://192.168.50.250/queue/lims.php?read=' || sample.c_protocol_number || '>' || sample.c_protocol_number || '</a>' else '' end,' ' order by sample.c_protocol_number) as pro3



from result 
inner join sample on sample.sample_number = result.sample_number
inner join project on project.name = sample.project
inner join test on test.test_number = result.test_number
where sample.status not in  ('A','X','R') and result.status not in  ('A','X','R') 
and (result.reportable= 'T' or result.reported_result='T') and result.displayed = 'T' and result.c_metodic_code is not null
and sample.c_protocol_number is not null and project.closed='F'
and project.date_created > now() - interval '2 month'
and project.customer <> 'TEST_EXAMPLE' ".$qroom."
and test.lab='$lab'
group by result.name
order by red desc,yellow desc, green desc";


#$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis),
#    c_proj_approval.urgency as c_urgency
#    from test 
#    left outer join sample on test.sample_number=sample.sample_number 
#    left outer join c_product on sample.c_product=c_product.id 
#    left outer join project on sample.project = project.name
#    left outer join storage_movement on storage_movement.object_id = sample.sample_number
#    inner join c_proj_approval on c_proj_approval.project = project.name 
#
#    where sample.status='U' 
#    and test.lab='$lab' and test.analysis not like '%\_%'
#    and project.customer <> 'TEST_EXAMPLE' ".$qroom."
#group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,c_proj_approval.urgency order by sample.text_id " ;
#    order by test.analysis,test.reported_name ";
#echo $query;


    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
// Вывод результатов в HTML
$total=0;
#echo "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    $total = $total + 1;
    echo "<tr><td>".$total."</td><td>".$line['name']."</td>
	<td width='30' bgcolor=\"#ff6666\" align=\"center\" >".$line['red']."</td>
	<td width='30' bgcolor=\"#ffff66\" align=\"center\">".$line['yellow']."</td>
	<td width='30' bgcolor=\"#66ff66\" align=\"center\">".$line['green']."</td>
	<td width='30' bgcolor=\"#ffffff\" align=\"center\">".($line['red']+$line['yellow']+$line['green'])."</td>
	<td width='30' bgcolor=\"#ff6666\" align=\"center\">".$line['pro']."</td>
	<td width='30' bgcolor=\"#ffff66\" align=\"center\">".$line['pro2']."</td>
	<td width='30' bgcolor=\"#66ff66\" align=\"center\">".$line['pro3']."</td>

</tr>";


}
#	echo "<tr><td colspan='2'><b>Всего  $total</b></td></tr>";

echo "</table>\n";


#echo "\n</td>";


#echo "</table>\n";



// Очистка результата
pg_free_result($result);
}


// Закрытие соединения
pg_close($dbconn);
?>
</html>
