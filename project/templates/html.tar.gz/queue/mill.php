
  <head>
      <link rel="stylesheet" href="css/table.css"> <!-- Путь к CSS файлу -->
  </head>

<?php 


// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


function query_plus($query) {
    //$query = "select name,value from list_entry where list = 'C_MILLING_TYPE' and name !='NONE_MILLING' order by name ";
    if ($query) {
//        echo $query;
        $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
        return pg_fetch_all($result);
    } else 
        return false;
}

function get_metod($analysis) {
#получаем номер (текст) метода из анализа
$ret = query_plus("select distinct(metod) from c_metodics where analysis = $analysis");
//print_r($ret);
//echo count($ret);

if (count($ret)==1)
    return "'".$ret[0]['metod']."'";
if (count($ret)==0) {
    echo "внимание, не найден метод для анализа $analysis";
    return false; }
if (count($ret)>1) {
    echo "Критическая ошибка, больше одного метода (".count($ret).") для анализа $analysis";
    exit(0);
    return false; }

}


function get_by_okpd($okpd) {
#получаем номер (текст) объекта по окад
$ret = query_plus("select name::varchar(45) from c_product where okpd = '$okpd' ");
return $ret[0]['name'];
//print_r($ret);
//echo count($ret);

}



# ajax1
if (isset($_REQUEST['term']) and isset($_REQUEST['type'])) {
//$gettxt = $_REQUEST['term'];
//$gettype = $_REQUEST['type'];
//preg_match ("/[a-zA-Zа-яА-Я ]+/msiu",$getorg,$matches1);
//preg_match ("/[a-zA-Zа-яА-Я ]+/msiu",$gettype,$matches2);

#print_r ($matches);
//$txt = $matches1[0];
$txt = pg_escape_string ( $_REQUEST['term'] );
$type = pg_escape_string ( $_REQUEST['type'] );

if (isset( $_REQUEST['location'])) 
    $location = pg_escape_string ( $_REQUEST['location'] );
else
    $location = "";
# 1 основное значение
# 2 описание
# 3 второе значение
#


switch ($type) {
case "indicator": 
$query = "select name,name from c_indicator where name2 ilike '%$txt%' or name1 ilike '%$txt%' or short_name ilike '%$txt%' limit 20";
break;

case "object": 
$query = "select name,concat(name,' ',okpd),okpd from c_product where name ilike '%$txt%' order by name limit 20";
break;

case "okpd": 
$query = "select okpd,concat(okpd,' ',name),name from c_product where okpd like '$txt%' order by length(okpd),okpd limit 20";
break;

case "analysis": 
$query = "select distinct(analysis),analysis,substring(analysis,7,2) from c_metodics where analysis is not null and  analysis ilike '%$txt%' and location like '%$location%'" ;
break;


}

// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
#$query = "select org,inn from fgis2inn where org ilike '%$org%' order by org_order desc limit 20";
#$query = "select name1 from c_indicator where name2 ilike '%$txt%' or name1 ilike '%$txt%' or short_name ilike '%$txt%'";

$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
$arr = array(); 

#$result = exec('grep  -iF "'.$org.'" kmapojolnaewrgf.php ',$arr); 
#echo 'grep -i "'.$org.'" kmapojolnaewrgf.php';


// Generate array with skills data 
$orgData = array(); 
$id=1;
while ($line = pg_fetch_array($result, null,  PGSQL_BOTH)) {
    $data['id']=$id;
    $data['value']=$line[1]; //описание
    $data['value1']=$line[0]; //основной ответ
    $data['value2']=$line[2]; //дополнительный ответ

    array_push($orgData,$data);
    $id +=1 ;
}


echo json_encode($orgData); 
exit(0);
}
### end ajax1


###########################################################################
# ajax2
if (isset($_REQUEST['read'])) {

#read	14.08.2019
#id	191
#comm	remove
    if (  (isset($_REQUEST['id'])) and (isset($_REQUEST['comm']))) {
        if ($_REQUEST['comm']=='remove') {
            $query = "update c_milling set removed='T' where id = ".pg_escape_string($_REQUEST['id']);
            $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
        }

        if ($_REQUEST['comm']=='recover') {
            $query = "update c_milling set removed='F' where id = ".pg_escape_string($_REQUEST['id']);
            $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
        }
}
    $read_data = $_REQUEST['read'];
//{"Строка запроса":{"read":"Получить записанные значения","location":"МБ","okpd":"11","indicator":"Clostridium perfringens"}}
    $query = "select * from c_milling where id >0 ";
    if ($_REQUEST['location']) 
        $query  = $query." and (location = '". pg_escape_string ($_REQUEST['location'] )."') " ;  
    else $ins['location']= "NULL";

    if ($_REQUEST['indicator']) 
        $query  = $query." and (indicator = '".  pg_escape_string ($_REQUEST['indicator'] )."' or indicator is null) ";  
    else $ins['indicator']= "NULL";

    if ($_REQUEST['okpd'])  {
#        and (object in (select parents('10.41')) or object is null) 

        $query  = $query." and (object in (select parents('".  pg_escape_string ($_REQUEST['okpd'] )."')) or object is null) ";  
#        echo  "req='".pg_escape_string ($_REQUEST['okpd'])."'";
        }
    else $ins['okpd']= "NULL";

    if ($_REQUEST['consistency']) 
        $query  = $query." and (consistency = '".  pg_escape_string ($_REQUEST['consistency'] )."' or consistency is null) ";  

#        echo   "'".  pg_escape_string ($_REQUEST['consistency'] )."'"; 
    else $ins['consistency']= "NULL";



$query = $query." order by indicator,metod,length(object) desc";
//echo "<p>".$query."</p>";
//$query = "select * from c_milling order by id";# where create_data::date  = '$read_data' order by id"";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Generate array with skills data 
$orgData = array(); 
$id=1;


echo "<table border='1' id='fgis_table'>";
echo "<tr>
<th>№</th>
<th>Подразделение</th>
<th>Показатель</th>
<th>ОКПД</th>
<th>Метод</th>
<th>Консистенция</th>
<th>Размол</th>
<th>Дата изменения</th>
<th>адрес</th>
</tr>";
while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
    if ($line[removed]=='T') {
        $re="re";
#        echo '<tr class="re">'; 
    } else {
        $re="nre";
#        echo "<tr>"; 
    }
#    id, protocol_number, protocol_data, address, org_name, org_inn, obj_name, obj_data, create_data, create_ip)
#раскрашиваем фон по подразделениям
switch ($line[location]) {
    case "СХРМИ":
        echo "<tr bgcolor='#009999'>";
        break;
    case "СФХМИ":
        echo "<tr bgcolor='#990099'>";
        break;
    case "СОМИ":
        echo "<tr bgcolor='#999900'>";
        break;
    default:
        echo "<tr bgcolor='#999999'>";
    }

    echo "
<td >".$line[id]."</td>
<td class='$re'>".$line[location]."</td>
<td class='$re'>".$line[indicator]."</td>
<td class='$re'>".get_by_okpd($line[object])." (".$line[object].")</td>
<td class='$re'>".$line[metod]."</td>
<td class='$re'>".$line[consistency]."</td>
<td class='$re'>".$line[milling_type]."</td>
<td class='$re'>".$line[create_data]."</td>
<td class='$re'>".$line[create_ip]."</td>
";
    if ($line[removed]=='T') {
        echo '<td><input onclick="re_nre('.$line[id].', \'recover\')" type="button" value="восстановить"></td>'; 
    } else {
        echo '<td><input onclick="re_nre('.$line[id].', \'remove\')" type="button" value="удалить"></td>'; 
#        echo "<td>удалить</td>"; 

    }


    echo "</tr>";

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
#echo $line;
#    $data['id']=$id;
#    $data['value']=$line[0];
#    $data['inn']=$line[1];
#    array_push($orgData,$data);
#    $id +=1 ;
}
echo "</table>";
#echo json_encode($orgData); 
exit(0);
}
### end ajax1





?>
<html>
<head>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- jQuery UI library -->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="datepicker-ru.js"></script>
<script src="jquery.validate.js"></script>
<script src="messages_ru.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script type="text/javascript" src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
</head>
<body>
<style>
.error {color:red;}
.re {text-decoration: line-through;}
.nre {text-decoration: none;}
</style>

<script>
$(function() {
    $.datepicker.setDefaults( $.datepicker.regional[ "ru" ] );

    $("#indicator").autocomplete({
        source: "mill.php?type=indicator",
    select: function (event, ui) {
            $( "#indicator" ).val( ui.item.value1 );
//            $( "#org_inn" ).val( ui.item.inn );
            return false;
        }
    });

    $("#analysis").autocomplete({
        source: "mill.php?type=analysis",
    select: function (event, ui) {
            $( "#location" ).val( ui.item.value2 );
            $( "#analysis" ).val( ui.item.value1 );
            return false;
        }
    });



    $("#object").autocomplete({
        source: "mill.php?type=object",
    select: function (event, ui) {
            $( "#object" ).val( ui.item.value1 );
            $( "#okpd" ).val( ui.item.value2 );
            return false;
        }
    });

    $("#okpd").autocomplete({
        source: "mill.php?type=okpd",
    select: function (event, ui) {
            $( "#okpd" ).val( ui.item.value1 );
            $( "#object" ).val( ui.item.value2 );
            return false;
        }
    });

//##############################################

    $("#indicator2").autocomplete({
        source: "mill.php?type=indicator",
    select: function (event, ui) {
            $( "#indicator2" ).val( ui.item.value1 );
//            $( "#org_inn" ).val( ui.item.inn );
            return false;
        }
    });

    $("#analysis2").autocomplete({
        source: "mill.php?type=analysis",
    select: function (event, ui) {
//            $( "#location" ).val( ui.item.value2 );
            $( "#analysis2" ).val( ui.item.value1 );
            return false;
        }
    });



    $("#object2").autocomplete({
        source: "mill.php?type=object",
    select: function (event, ui) {
            $( "#object2" ).val( ui.item.value1 );
            $( "#okpd2" ).val( ui.item.value2 );
            return false;
        }
    });

    $("#okpd2").autocomplete({
        source: "mill.php?type=okpd",
    select: function (event, ui) {
            $( "#okpd2" ).val( ui.item.value1 );
            $( "#object2" ).val( ui.item.value2 );
            return false;
        }
    });





    $( "#location" ).change(function() {
//     alert( $( "#analisys" ).val());
        $( "#analysis" ).val("");
    });



    $( "#read" ).click(function() {
//      alert( $( "#read" ).val( ));
    $.get("mill.php", { 
        read: $( "#read" ).val( ),
        location: $("#location2").val (),
        okpd: $("#okpd2").val (),
        indicator: $("#indicator2").val (),
        consistency: $("#consistency2").val (),

    })
        .done(function(data) {
         $("#protocols").html( data );

        $('#example').DataTable({  
            "ajax" : data
            });
        });
    });



 

//    $( "#read" ).datepicker( );

    $( "#protocol_data" ).datepicker( );
    $( "#obj_data" ).datepicker( );
    $( "#mainForm" ).validate();

	$.validator.messages.required = " << Заполните поле!";
	$.validator.messages.email = "Неверный формат email";
	$.validator.messages.url = "Неверный формат url, начните с http://";

});

    function re_nre(re_id, comm) {
//    alert(re_id);
//    alert(comm);

//      alert( $( this ).parent().html() );
    $.get("mill.php", { 
            read: $( "#read" ).val( ),
            id: re_id,
            comm: comm

            })
        .done(function(data) {
         $("#protocols").html( data );
        });
    };

</script>

<script>
document.addEventListener('DOMContentLoaded', () => {

    const getSort = ({ target }) => {
        const order = (target.dataset.order = -(target.dataset.order || -1));
        const index = [...target.parentNode.cells].indexOf(target);
        const collator = new Intl.Collator(['en', 'ru'], { numeric: true });
        const comparator = (index, order) => (a, b) => order * collator.compare(
            a.children[index].innerHTML,
            b.children[index].innerHTML
        );
        
        for(const tBody of target.closest('table').tBodies)
            tBody.append(...[...tBody.rows].sort(comparator(index, order)));

        for(const cell of target.parentNode.cells)
            cell.classList.toggle('sorted', cell === target);
    };
    
    document.querySelectorAll('.table_sort thead').forEach(tableTH => tableTH.addEventListener('click', () => getSort(event)));
    
});
</script>




<?php



#if ($_SERVER['REMOTE_ADDR']=="192.168.50.101") {
#
#
#echo "fgis";
#exit(0);
#}





if (in_array($_SERVER['REMOTE_ADDR'], $ip)) {
#echo "MILL for ".$_SERVER['REMOTE_ADDR'];
#exit(0);
#} ==>перенесено в после формы ввода но перед формой чтения





### post
#Array
#(
#    [number_protocol] => 123
#    [date_protocol] => 11.08.2019
#    [place] => Корпус Б
#    [org_input] => ООО «ЭкоНиваАгро»
#    [org_inn] => 1234567890
#    [full_object] => йф2й
#    [date_object] => 29.08.2019
#    [submit] => Отправить
#)
#192.168.50.102

#INSERT INTO public.fgis2(
#    id, protocol_number, protocol_data, address, org_name, org_inn, obj_name, obj_data, create_data, create_ip)
#    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);


 if  ( $_SERVER['REQUEST_METHOD'] == "POST"){
//        print_r($_POST);
#        echo $_SERVER['REMOTE_ADDR'];
    $ins=array();
    $ins['id']='';

    $ins['location'] =    "'".pg_escape_string ($_POST['location'])."'";

    if ($_POST['analysis']) {
        $ins['metod'] = get_metod("'".pg_escape_string ($_POST['analysis'])."'");

    } else $ins['metod']= "NULL";

    if ($_POST['indicator'])  $ins['indicator']=   "'".  pg_escape_string ($_POST['indicator'] )."'";  else $ins['indicator']= "NULL";

    if ($_POST['object']) $ins['object']   =    "'". pg_escape_string ($_POST['object'] )."'";  else $ins['object']= "NULL";

    if ($_POST['okpd']) $ins['okpd']    =     "'".pg_escape_string ($_POST['okpd'])."'";  else $ins['okpd']= "NULL";

    if ($_POST['consistency']) $ins['consistency']=   "'".  pg_escape_string ($_POST['consistency'] )."'"; else $ins['consistency']= "NULL";

    if ($_POST['milling']) $ins['milling']    =    "'". pg_escape_string ($_POST['milling'] )."'";  else $ins['milling']= "NULL";

    $ins['submit']  =    pg_escape_string (   $_POST['submit'] );


// echo  $ins['metod'], $ins['indicator'],$ins['submit'];

if (($ins['metod']!="NULL") and ($ins['indicator']=="NULL") and ($ins['okpd']== "NULL") and ($ins['submit']=="Записать")) {
    echo "<p>Добавление всех компоненов и всех объектов анализа ".$_POST['analysis']."</p>";

    $query = "select indicator,object_group from c_metodics where analysis = '".pg_escape_string ($_POST['analysis'])."'";
    foreach(query_plus($query,true) as $line) {
        echo "<p><b>Показатель ".$line['indicator']."</b></p>";

$analysis_okpd = query_plus("select c_product.okpd from c_product_group,c_product where c_product_group.id = ".$line['object_group']."  
 and c_product.id::text in ( select regexp_split_to_table (c_product_group.c_product,',[ ]*') ) ");
    foreach ($analysis_okpd as $one_okpd) {
#        print_r($one_okpd);


    $query = "INSERT INTO public.c_milling(
        location, indicator, object, metod, consistency, milling_type, create_ip)
        VALUES (".$ins['location'].", '". $line['indicator']."', '".$one_okpd['okpd']."', ".$ins['metod'].", ".$ins['consistency'].", ".$ins['milling'].", '".$_SERVER['REMOTE_ADDR']."');";
        
    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
    if ($result) 
        echo "<p>запись успешно добавлена</p>";
    else 
        echo "<p>ошибка при добавлении данных</p>";
    } //foreach one_okpd

    } //foreach indicator



#    exit(0);
} elseif ($ins['submit']=="Записать") {
$query = "INSERT INTO public.c_milling(
    location, indicator, object, metod, consistency, milling_type, create_ip)
    VALUES (".$ins['location'].", ". $ins['indicator'].", ".$ins['okpd'].", ".$ins['metod'].", ".$ins['consistency'].", ".$ins['milling'].", '".$_SERVER['REMOTE_ADDR']."');";

$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());


if ($result) {
    echo "<b>запись успешно добавлена</b>";
 } else {
    echo "ошибка при добавлении данных";
}
}



#  $res = pg_insert($dbconn, 'fgis2', $ins);
#    echo "res start";
#    print_r($res);
#    echo pg_last_error();
#    echo pg_result_error ($res);
#    echo "res end";
#  if ($res) {
#      echo "Данные из POST успешно внесены в журнал\n";
# } else {
#      echo "Пользователь прислал неверные данные\n";
#  }




}
#echo $_SERVER['REQUEST_METHOD'];
#exit(0);



###end post




?>





<form method="post" id="mainForm">
<table border="1">

<tr>
<td>Подразделение</td>
<td>
<select class="required" name="location" id="location">
    <option></option>
    <option value="СХРМИ">СХРМИ</option>
    <option value="СФХМИ">СФХМИ</option>
    <option value="ГРМИ">ГРМИ</option>
    <option value="ГМГМИ">ГМГМИ</option>
    <option value="ГИФА">ГИФА</option>
    <option value="СОМИ">СОМИ</option>
    <option value="СЕРОЛОГИЯ">СЕРОЛОГИЯ</option>
    <option value="СМБМИ">СМБМИ</option>
 </select>
</td>
<td>Подразделение для которого настраивается размол, обязательное поле</td>
</tr>
<tr>
<td>Анализ (многокомпонетный)</td>
<td><input  type="text" name="analysis" id="analysis" size="45"> </td>
<td>Анализ, для которого настраивается размол, если не заполнять поле показатель, будет примерено для всех показателей этого анализа</td>
</tr>



<tr>
<td>Показатель</td>
<td><input  type="text" name="indicator" id="indicator" size="45"> </td>
<td>показатель для которого настраивается размол, если не заполнено - для всех показателей анализа</td>
</tr>
<tr>


<tr>
<td>Объект(текст)</td>
<td><input  type="text" name="object" id="object" size="45"/></td>
<td rowspan="2">объекты для которых настраивается размол (связанные поля)</td>
</tr>

<tr>
<td>Объект(ОКПД)</td>
<td><input  type="text" name="okpd" id="okpd" size="45"/></td>
</tr>

<tr>
<td>Консистенция</td>
<!--td><input type="text" name="consistency" id="consistency" size="45" /></td-->
<td><select  name="consistency" id="consistency">
    <option></option>
<?php
foreach (query_plus("select name,value from list_entry where list = 'C_CONSISTENCY' order by order_number ") as $line)
    echo '<option value="'.$line['name'].'">'.$line['value'].'</option>';
?>
</select>
<td>исходная консистенция образца</td>
</tr>

<tr>
<td>Размол</td>
<td><select class="required" name="milling" id="milling">
    <option></option>

<?php
foreach (query_plus("select name,value from list_entry where list = 'C_MILLING_TYPE' and name !='NONE_MILLING' order by name ") as $line)
    echo '<option value="'.$line['name'].'">'.$line['value'].'</option>';
?>

</select>
<td>Необходимый размол</td>
</tr>


<tr>
<td></td>
<td></td>
<td></td>
</tr>




<tr>
<td><input type="submit" name="submit" value="Записать"/></td>
<td><input type="submit" name="submit" value="Прочитать"/></td>
</tr>
</table>
</form>


<?php 
#if ip
}
?>

<hr align="center" width="100%" size="5" color="#dddddd" /> 
<table>
<tr><td><h2>Чтение правил размола</h2></td></tr>

<tr><td>Подразделение</td>
<td>
<select class="required" name="location2" id="location2">
    <option></option>
    <option value="СХРМИ">СХРМИ</option>
    <option value="СФХМИ">СФХМИ</option>
    <option value="ГРМИ">ГРМИ</option>
    <option value="ГМГМИ">ГМГМИ</option>
    <option value="ГИФА">ГИФА</option>
    <option value="СОМИ">СОМИ</option>
    <option value="СЕРОЛОГИЯ">СЕРОЛОГИЯ</option>
    <option value="СМБМИ">СМБМИ</option>
 </select>
</td></tr>


<tr>
<td>Показатель</td>
<td><input  type="text" name="indicator2" id="indicator2" size="45"> </td>
</tr>
<tr>
<tr>
<td>Объект(текст)</td>
<td><input  type="text" name="object2" id="object2" size="45"/></td>
</tr>

<tr>
<td>Объект(ОКПД)</td>
<td><input  type="text" name="okpd2" id="okpd2" size="45"/></td>
</tr>

<tr>
<td>Консистенция</td>
<td><select  name="consistency2" id="consistency2">
    <option></option>
<?php
foreach (query_plus("select name,value from list_entry where list = 'C_CONSISTENCY' order by order_number ") as $line)
    echo '<option value="'.$line['name'].'">'.$line['value'].'</option>';
?>
</select>
</tr>




<tr><td><input type="button" name="read" value="Получить записанные значения" id="read" size="45" /></td></tr>
</table>
<table>
<tr><td id="protocols"></td></tr>
</table>
</body>
</html>
