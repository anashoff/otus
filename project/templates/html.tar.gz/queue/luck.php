<?php
include "auth.php"
#$ip = array(
#"192.168.50.102", #developer
#"192.168.50.28", #k1
#"192.168.50.29", #k2
#"192.168.50.30", #k3
#"192.168.50.22", #NE
#"192.168.50.82", #valentina wifi
#"192.168.50.83", #valentina lan
#"192.168.50.121", #feilx lan
#"192.168.50.1", #router
#"192.168.50.107", # лимс сервер
#"192.168.50.32", #Маргарита
#"192.168.50.165", #Максим
#"192.168.50.131",  #feilx vpn
#"192.168.50.16", #Антон
#"192.168.50.93", #Валентина lan2
#"192.168.50.95", #Максим windows
#"192.168.50.96" #Максим phone
#);

#if (!in_array($_SERVER['REMOTE_ADDR'], $ip)) {
#echo "LIMS for ".$_SERVER['REMOTE_ADDR'];
#exit(0);
#}

?>
<style type="text/css">
.error {color:red;}
.re {text-decoration: line-through;}
.nre {text-decoration: none;}

.status_A { background-color: MediumSeaGreen; }
.status_R { background-color: lightgray; text-decoration:line-through; }
.status_X { background-color: Dimgray; text-decoration:line-through;}
.status_N { background-color: Tomato; }
.status_E { background-color: Turquoise; }
.status_M { background-color: DarkTurquoise; }

</style>

<?php




// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");

$column = ["номер результата"=>"result_number",
    "Анализ" => "analysis",
    "Компонент" => "name",
    "Значение" => "entry",
    "Округление" => "round",
    "знаки после запятой" => "places",
    "значащие цифры" => "places_2",
    "Форматированное <br>значение" => "formatted_entry",
    "Неопределенность" => "t_uncertainty",
    "ЕИ методики" => "units",
    "ЕИ клиента" => "c_units",
    "В протокол" => "protocol_value",
    "Неопр.протокол" => "protocol_uncertainty",
    "В инф.письмо" => "protocol_value3",
    "Статус результата" => "status",
    "тип протокола"=>"protocol_type",
    "Видимость"=>"displayed"
];

$column2 = ["№"=>"sample_number",
    "номер образца"=>"c_protocol_number",
    "Проект"=>"project",
    "Основной образец"=>"parent_aliquot",

    "заказчик"=>"customer",
    "дата регистрации"=>"login_date",
    "ГПП"=>"login_by",
    "Название образца"=>"sample_name",
    "Статус"=>"status"

];


#ajax0
if (isset($_REQUEST['group'])) {
$getgroup = $_REQUEST['group'];
preg_match ("/[a-zA-Zа-яА-Я0-9-]+/msiu",$getgroup,$matches);
#print_r ($matches);
$group = $matches[0];

$query = "select sample.c_protocol_number,sample.sample_name,result.name,
    case when protocol_value is not null then protocol_value else result.formatted_entry || ' [первичное]' end,
    case when result.protocol_comment_unit is not null then 'в ' || result.protocol_comment_value || ' ' || units.display_string 
        when protocol_value is not null then  p_units.display_string
        else  r_units.display_string || ' [первичное]' end, 
sample.status as sstatus,result.status as rstatus,
sample.original_sample
    from result
    inner join test on test.test_number = result.test_number
    inner join sample on sample.sample_number = test.sample_number 
    inner join project on project.name = sample.project
    left outer join units on units.unit_code = result.protocol_comment_unit
    left outer join units p_units on p_units.unit_code = result.protocol_unit
    left outer join units r_units on r_units.unit_code = result.units
    where project.name='".$group."' and result.reportable='T' and result.displayed='T'
    order by result.name,sample.original_sample ";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
?>
<table border='1px'>
<tr>
<th>№</th>
<th>Шифр пробы</th>
<th>Название образца</th>
<th>Наименование показателя</th>
<th>Результат</th>
<th>ЕИ</th>
<th>sample.status</th>
<th>result.status</th>
</tr>
<?php

while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {
    $id +=1 ;
if ($line[2] != $oldparam) {
    echo '<tr><th colspan="8">'.$line[2].'</td></tr>';
    $oldparam=$line[2];
    }


echo "<tr><td>";
echo $id;
echo "</td><td>";
echo $line[0];
echo "</td><td>";
echo $line[1];
echo "</td><td>";
echo $line[2];
echo "</td><td>";
echo $line[3];
echo "</td><td>";
echo $line[4];
echo "</td><td>";
echo $line[5];
echo "</td><td>";
echo $line[6];
echo "</td><td>";
echo $line[7];
echo "</td><td>";
echo $line[8];
echo "</td></tr>";





}
echo "</table>";


}
#end ajax0





# ajax1
if (isset($_REQUEST['term'])) {
$getorg = $_REQUEST['term'];

preg_match ("/[a-zA-Zа-яА-Я ]+/msiu",$getorg,$matches);
#print_r ($matches);
$org = $matches[0];
$org = pg_escape_string ( $_REQUEST['term'] );
// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select org,inn from fgis2inn where org ilike '%$org%' order by org_order desc limit 20";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
$arr = array(); 

#столбцы для отображения данных result



#$result = exec('grep  -iF "'.$org.'" kmapojolnaewrgf.php ',$arr); 
#echo 'grep -i "'.$org.'" kmapojolnaewrgf.php';


// Generate array with skills data 
$orgData = array(); 
$id=1;

while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {
    $data['id']=$id;
    $data['value']=$line[0];
    $data['inn']=$line[1];
    array_push($orgData,$data);
    $id +=1 ;
}
echo json_encode($orgData); 
exit(0);
}
### end ajax1

# ajax2
if (isset($_REQUEST['read']) or isset($_REQUEST['read4'])) {


$read_data = $_REQUEST['read'];

#$query = "select * from fgis2 where create_data::date  = '$read_data' order by id";

// Generate array with skills data 
$orgData = array(); 
$id=1;
#====
if (isset($_REQUEST['read'])) {
#$query = "select * from result where sample_number in (select sample_number from sample where c_protocol_number like '".pg_escape_string($_REQUEST['read'])."%') and displayed='T' and reported_result='T'";

#$query = "select * from result where sample_number in (select sample_number from sample where c_protocol_number like '".pg_escape_string($_REQUEST['read'])."%') and displayed='T' and reported_result='T' 
#order by analysis,test_number,order_number";

$readstr = pg_escape_string($_REQUEST['read']);
if (strpos($readstr, ".") >0) {

$query = "select * from result where sample_number in (select sample_number from sample where c_protocol_number = left('".$readstr."',length('".$readstr."')-1)) and displayed='T' and reportable='T' 
order by analysis,test_number,order_number";

$query2 = "select sample.*,project.customer from sample 
    inner join project on project.name=sample.project
    where sample.c_protocol_number = left('".$readstr."',length('".$readstr."')-1) and parent_aliquot=0 order by sample_number desc limit 20";
}
else {
$query = "select * from result where sample_number in (select sample_number from sample where c_protocol_number like '".pg_escape_string($_REQUEST['read'])."%') and displayed='T' and reportable='T' 
order by analysis,test_number,order_number";

    $query2 = "select sample.*,project.customer from sample 
    inner join project on project.name=sample.project 
where  sample.c_protocol_number like '".pg_escape_string($_REQUEST['read'])."%' and parent_aliquot=0 order by sample_number desc limit 20";
}


}
if (isset($_REQUEST['read4'])) {
$query = "select * from result where entry like '%".pg_escape_string($_REQUEST['read4'])."%' limit 50";

$query2 = "select * from sample 
inner join result on result.sample_number = sample.sample_number
where result.entry like '%".pg_escape_string($_REQUEST['read4'])."%' limit 30";

#c_protocol_number='".pg_escape_string($_REQUEST['read4'])."' and parent_aliquot=0 order by sample_number desc limit 1";
}

$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

$result2 = pg_query($query2) or die('Ошибка запроса: ' . pg_last_error());

echo "<table border='1' id='protocol_table'>
<th> </th>";

foreach ($column2 as $key=>$one)
    echo "<th>".$key."</th>";

while ($line2 = pg_fetch_array($result2, null,  PGSQL_ASSOC)) {
$sc = "white";
if ($line2["status"]=='A')
    $sc = "MediumSeaGreen";
if ($line2["status"]=='X')
    $sc = "Dimgray";
if ($line2["status"]=='N')
    $sc = "Tomato";

#----
echo "<tr style = 'background-color:".$sc."'>";
echo "<td><input onclick='get_protocol()' type='button' value='открыть протокол'></td>";
foreach ($column2 as $one) {

echo "<td>";
        echo $line2[$one];
echo "</td>";
}


echo "<td><a target = \"_blank\" href=\"http://192.168.50.250/queue/blob.php?read=".$line2['project']."\">Заявка проекта ".$line2['project']."</a></td>";
echo "</tr>";

}

echo "</table>";
#=====

#=====



echo "Отчет по ".pg_escape_string($_REQUEST['read']);
echo "<table border='1' id='fgis_table'>";

foreach ($column as $key=>$one)
    echo "<th>".$key."</th>";



while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
#----
echo "<tr>";


foreach ($column as $one) {

echo "<td class = 'status_".$line["status"]."'>";
if ($one=="analysis")
    echo "<a href='http://192.168.50.250/wiki/index.php/".$line[$one]."' target='_blank'>".$line[$one]." </a></td>";
#elseif ($one=="name")
#{
#}
elseif ($one=="c_units")
{
    if ( $line["c_units"] != $line["units"])
        echo "<b>".$line[$one]."</b>";
    else
        echo $line[$one];
}
else
    echo $line[$one];
echo "</td>";
  }

echo "</tr>";

} #строка

echo "</table>";

exit(0);
}
### end ajax1

if (isset($_REQUEST['read2']) or isset($_REQUEST['read3'])) {

if (isset($_REQUEST['read2'])) {
$query2 = "select sample.*,project.customer from sample
    inner join project on project.name=sample.project 
    where (sample_name ilike '%".pg_escape_string($_REQUEST['read2'])."%' or sample.project in (select project from t_proji_attach where description like '%".pg_escape_string($_REQUEST['read2'])."%' ) )
and parent_aliquot=0  order by sample_number desc limit 50";
}

if (isset($_REQUEST['read3'])) {
#$query2 = "select * from sample where sample_name ilike '%".pg_escape_string($_REQUEST['read3'])."%' and parent_aliquot=0 order by sample_number desc limit 20";
$query2 = "select sample.*,project.customer from sample 
    inner join project on project.name=sample.project
    inner join customer on customer.name=project.customer
    where (customer.company_name ilike '%".pg_escape_string($_REQUEST['read3'])."%' 
	or customer.name ilike '%".pg_escape_string($_REQUEST['read3'])."%') and parent_aliquot=0 
    order by sample_number desc limit 50";
#print($query2);

}


if (isset($_REQUEST['read4'])) {
$query2 = "select sample.*,project.customer from sample 
    inner join project on project.name=sample.project
    inner join customer on customer.name=project.customer
    where customer.company_name ilike '%".pg_escape_string($_REQUEST['read4'])."%' and parent_aliquot=0 
    order by sample_number desc limit 20";

}




$result2 = pg_query($query2) or die('Ошибка запроса: ' . pg_last_error());

echo "<table border='1' id='protocol_table'>";
echo "<th></th>";
foreach ($column2 as $key=>$one)
    echo "<th>".$key."</th>";

while ($line2 = pg_fetch_array($result2, null,  PGSQL_ASSOC)) {

$sc = "white";
if ($line2["status"]=='A')
    $sc = "MediumSeaGreen";
if ($line2["status"]=='X')
    $sc = "Dimgray";
if ($line2["status"]=='N')
    $sc = "Tomato";



#----
echo "<tr class = 'status_".$line2["status"]."'>";
echo "<td><input onclick='get_protocol()' type='button' value='открыть протокол'></td>";

foreach ($column2 as $one) {

echo "<td>";
        echo $line2[$one];
echo "</td>";
}
echo "<td><a target = \"_blank\" href=\"http://192.168.50.250/queue/blob.php?read=".$line2['project']."\">Заявка проекта ".$line2['project']."</a></td>";
echo "</tr>";
}
#print($query2);
#print_r($line2);
echo "</table>";
exit(0);
}







?>


<html>
<head>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- jQuery UI library -->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="datepicker-ru.js"></script>
<script src="jquery.validate.js"></script>
<script src="messages_ru.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script type="text/javascript" src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>




</head>


<style type="text/css">
.error {color:red;}
.re {text-decoration: line-through;}
.nre {text-decoration: none;}

.status_A { background-color: MediumSeaGreen; }
.status_R { background-color: lightgray; text-decoration:line-through; }
.status_X { background-color: Dimgray; text-decoration:line-through;}
.status_N { background-color: Tomato; }
.status_E { background-color: Turquoise; }
.status_M { background-color: DarkTurquoise; }

</style>



<script>
$(function() {
    $.datepicker.setDefaults( $.datepicker.regional[ "ru" ] );
    $("#org_name").autocomplete({
        source: "fgis.php",
    select: function (event, ui) {
            $( "#org_name" ).val( ui.item.value );
            $( "#org_inn" ).val( ui.item.inn );
            return false;
        }
    });
    $( "#org_name" ).keyup(function() {
      $( "#org_inn" ).val("" );
    });
    $('#fgis_table').DataTable();


    $( "#read" ).change(function() {
//      alert( $( "#read" ).val( ));
    $.get("lims.php", { read: $( "#read" ).val( ) })
        .done(function(data) {
         $("#protocols").html( data );
        $( "#read2" ).val("");
         $("#protocols2").html("" );
        });
    });

    $( "#read2" ).change(function() {
//      alert( $( "#read" ).val( ));
    $.get("lims.php", { read2: $( "#read2" ).val( ) })
        .done(function(data) {
        $( "#read" ).val("");
         $("#protocols2").html( data );

        });
    });

    $( "#read3" ).change(function() {
//      alert( $( "#read" ).val( ));
    $.get("lims.php", { read3: $( "#read3" ).val( ) })
        .done(function(data) {
        $( "#read" ).val("");
        $( "#read2" ).val("");
         $("#protocols2").html( data );

        });
    });

    $( "#read4" ).change(function() {
//      alert( $( "#read" ).val( ));
    $.get("lims.php", { read4: $( "#read4" ).val( ) })
        .done(function(data) {
        $( "#read" ).val("");
        $( "#read2" ).val("");
         $("#protocols2").html( data );

        });
    });

 

//    $( "#read" ).datepicker( );

    $( "#protocol_data" ).datepicker( );
    $( "#obj_data" ).datepicker( );
    $( "#mainForm" ).validate();

	$.validator.messages.required = " << Заполните поле!";
	$.validator.messages.email = "Неверный формат email";
	$.validator.messages.url = "Неверный формат url, начните с http://";

});



    function re_nre(re_id, comm) {
//    alert(re_id);
//    alert(comm);

//      alert( $( this ).parent().html() );
    $.get("fgis.php", { 
            read: $( "#read" ).val( ),
            id: re_id,
            comm: comm

            })
        .done(function(data) {
         $("#protocols").html( data );
        });




    };

    function get_protocol () {
    row = $(event.target).parent().parent().children();
//    alert($(row[1]).html());

    $.get("lims.php", { read: $(row[2]).html() })
        .done(function(data) {
         $("#protocols").html( data );
//         $("#protocols2").html("");
        });
    


};


</script>

<script>
document.addEventListener('DOMContentLoaded', () => {

    const getSort = ({ target }) => {
        const order = (target.dataset.order = -(target.dataset.order || -1));
        const index = [...target.parentNode.cells].indexOf(target);
        const collator = new Intl.Collator(['en', 'ru'], { numeric: true });
        const comparator = (index, order) => (a, b) => order * collator.compare(
            a.children[index].innerHTML,
            b.children[index].innerHTML
        );
        
        for(const tBody of target.closest('table').tBodies)
            tBody.append(...[...tBody.rows].sort(comparator(index, order)));

        for(const cell of target.parentNode.cells)
            cell.classList.toggle('sorted', cell === target);
    };
    
    document.querySelectorAll('.table_sort thead').forEach(tableTH => tableTH.addEventListener('click', () => getSort(event)));
    
});
</script>
<?php
$query = "select name from lab";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
//   <p><input type="checkbox" name="a" value="1417"> 1417</p>
// Вывод результатов в HTML
#echo "<table border='1px'>\n";
#echo "\t<tr>\n";
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {

#    foreach ($line as $col_value) {
        echo "\t\t<p><input type=\"checkbox\" name=\"lab\" value=\"$line[0]\">$line[0]</p>\n";
#    }
}
echo "<p><input type=\"checkbox\" name=\"lab\" value=\"XР-134\">ХР-134</p>";
echo "<p><input type=\"checkbox\" name=\"lab\" value=\"ХР-216\">ХР-216</p>";
echo "<p><input type=\"checkbox\" name=\"lab\" value=\"ХР-218\">ХР-218</p>";
echo "<p><input type=\"checkbox\" name=\"lab\" value=\"ХР-219\">ХР-219</p>";
echo "<p><input type=\"checkbox\" name=\"lab\" value=\"ХР-220\">ХР-220</p>";
echo "<p><input type=\"checkbox\" name=\"lab\" value=\"ХР-221\">ХР-221</p>";
#    echo "\t</tr>\n";

#echo "</table>\n";


?>


<table border="1px">
<tr>
    <td><h2>Поиск по номеру протокола</h2></td>
    <td><h2>Поиск по тексту в протоколе</h2></td>
    <td><h2>Поиск по заказчику</h2></td>
    <td><h2>Поиск по результату</h2></td></tr>
<tr>
    <td><input type="text" name="read" id="read" size="50" /></td>
    <td><input type="text" name="read2" id="read2" size="50" /></td>
    <td><input type="text" name="read3" id="read3" size="50" /></td>
    <td><input type="text" name="read4" id="read4" size="50" /></td>

</tr>
<tr><td  colspan="4" id="protocols2"></td></tr>
<tr><td  colspan="4" id="protocols"></td></tr>

</table>

</html>
