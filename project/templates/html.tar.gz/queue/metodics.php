<html>
  <head>
      <link rel="stylesheet" href="../css/table.css"> <!-- Путь к CSS файлу -->
  </head>
<?php

// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");

function get_c_metodics($sop) {
$n = 0;
#$query = "select description from c_metodics where c_metodics.analysis='$sop'";
$query = "select c_indicator.name1 from c_metodics 
left join c_indicator on c_indicator.name =c_metodics.indicator 
where c_metodics.analysis='$sop' 
and version = (select max(version) from c_metodics where analysis='$sop' )";


$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
$ret = "";
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {
    $n +=1;
    $ret = $ret.$n.". ".$line[0]."<br>\n";
}
if ($n==0) $ret=" --- ";

return $ret;
}





// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select name from lab";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
echo "<table border='1px'>\n";
echo "\t<tr>\n";
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {

#    foreach ($line as $col_value) {
        echo "\t\t<td><a href='/queue/metodics.php?lab=$line[0]' class=button-style>$line[0]</td>\n";
#    }
}
    echo "\t\t<td><a href='/' class=button-style>Главная</td>\n";

    echo "\t</tr>\n";

echo "</table>\n";

// Очистка результата
pg_free_result($result);




$getlab = $_REQUEST['lab'];

#echo $lab;
preg_match ("/[a-zA-Zа-яА-Я]+/msiu",$getlab,$matches);
#print_r ($matches);
$lab = $matches[0];

#exit(0);

if (strlen($lab)>0) {
#1
echo "<table border='1px'>\n";
#echo "<tr><td  style='vertical-align:top'>\n";

$query = "SELECT split_part(o.name, '.',4)::int as n,split_part(o.name, '.',5)::int as l,o.*
FROM analysis o                   
  LEFT JOIN analysis b             
      ON o.name = b.name AND o.version < b.version
WHERE b.version is NULL  and o.group_name <> 'HIDDEN' and o.active= 'T' and o.version > 1 and o.lab='$lab'
and o.name like 'СОП.М.%' and o.name not like '%\_%'
  order by n,l";
#2
#echo "<table>\n";
#echo "<tr><th colspan='4'>В процессе регистрации</th></tr>\n\n";

#echo "<tr><td>";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab'";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.text_id,test.analysis,test.reported_name,c_product.name from test left outer join sample on test.sample_number=sample.sample_number left outer join c_product on sample.c_product=c_product.id where sample.status='U' and test.lab='$lab' order by test.analysis,test.reported_name ";

    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
$total=0;
#echo "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    echo "\t<tr>\n";
    $total = $total + 1;
#    foreach ($line as $col_value) {
    echo "\t\t<td>".$line['name']."</td>\n";
    echo "\t<td>".get_c_metodics($line['name'])."</td>\n";
    echo "\t\t<td>".$line['description']."</td>\n";

    echo "\t</tr>\n";
}

echo "<tr><td colspan='4'><b>Всего $total</b></td></tr>";

#echo "</table>\n";


#echo "\n</td>";

###################### 
#echo "<td  style='vertical-align:top'>";
#echo "<table>";
#echo "<tr><td colspan='4'>Всего  в работе $total</td></tr>";

echo "</table>\n";



// Очистка результата
pg_free_result($result);
}















// Закрытие соединения
pg_close($dbconn);
?>
</html>
