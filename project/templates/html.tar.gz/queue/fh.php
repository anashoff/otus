<html>
<head>
 <!--meta http-equiv="refresh" content="300"-->
<title>Давай считать!!</title>
</head>
<body>
<h1>Давай считать!! v.1.0.</h1>
<?php

// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.50.251 dbname=LIMS_PUSCHINO_DEV user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


function draw_sample($line,$col) {
# рисуем этикетку единичного образца
#картинка | код | показатель
#         | соп | матрица |

# для первого столбца проверяем нет ли витаминов
if ($col <= 2) {
$queryfreeze = "select count(test_number)
from test
inner join sample on test.sample_number=sample.sample_number
where
test.analysis in ('СОП.М.ХР.011.1','СОП.М.ХР.013.1','СОП.М.ХР.018.1','СОП.М.ХР.020.1','СОП.М.ХР.021.1', --витамин а
'СОП.М.ХР.011.2','СОП.М.ХР.013.1','СОП.М.ХР.016.1','СОП.М.ХР.018.1','СОП.М.ХР.020.2','СОП.М.ХР.021.1','СОП.М.ХР.040.1','СОП.М.ХР.063.1' --витамин e
) and
sample.c_protocol_number = '".$line['c_protocol_number']."'";
$resultfreeze = pg_query($queryfreeze) or die('Ошибка запроса: ' . pg_last_error());
$vit = pg_fetch_array($resultfreeze, null,  PGSQL_NUM )[0];
} else
$vit = 0;


if ($line['c_urgency'] == 'STD')
{
    if ($vit==0) {
        $bg = "#ccc" ; #цвет шапки
        $bg2 = "#ccc"; #цвет тела
    } else {
        $bg = "#ccc" ; #цвет шапки
        $bg2 = "#99f" ;
    }
    $urg = "";
}
else
{
    if ($vit==0) {
        $bg = "#Faa";
        $bg2 = "#Faa"; #цвет тела
    } else {
        $bg = "#F33";
        $bg2 = "#99f" ;
    }
    
    $urg  = " (СРОЧНО)";
}
#echo $line['bo'];
if (strlen($line['bo'])>0) {
$bo='<tr><td colspan="3">'.$line['bo'].'</td></tr>';
} else 
$bo = '';
#echo $bo;

$ret = '<table border="1" bgcolor="'.$bg.'">
<tr bgcolor="'.$bg.'">
    <td rowspan="2"><img></img></td>
    <td><b>'.$line['c_protocol_number'].$urg.'</b></td>
    <td>'.$line['text_id'].'</td>
    <td></td>
</tr>
<tr bgcolor="'.$bg2.'">
    <td colspan="3" colspan="3"><u>'.$line['name'].'</u></td>
</tr>	
<tr bgcolor="'.$bg2.'">
    <td>'.$line['analysis'].'</td>
    <td colspan="3">'.$line['string_agg'].'</td>
</tr>'.$bo.'</table>';

return $ret;

}

##########################################################

// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select sample.project,sample.sample_number,sample.c_protocol_number,'[' || c_product.okpd || '] ' || c_product.name,sample.status,sample.old_status 
from sample
--inner join sample on sample.sample_number = test.sample_number
inner join project on project.name = sample.project
inner join c_product  on c_product.id = sample.c_product
where sample.status in ('P','C') and project.closed='F' and sample.parent_aliquot != 0 
and aliquot_group = 'ФХ'
and sample_number in (select sample_number from test where (analysis like 'СОП.М.ФХ.001.%' or analysis like 'СОП.М.ФХ.003.%'or analysis like 'СОП.М.ФХ.006.%' or analysis like 'СОП.М.ФХ.008.%' or analysis like 'СОП.М.ФХ.015.%')
and test.status not in ('X','I','R') )

order by sample.project desc
";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
// Вывод результатов в HTML
echo "<table><tr valign='top'><td>";
?>
<table border='1px'>
<tr>
<th>Проект</th>
<th>Шифр образца</th>
<th>ОКПД</th>
<th>статус</th>
<th>прошлый статус</th>

<?php
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {
    $rbg1 = "#fff";
    if ($line[4]=='P') $rbg1 = "#3f9";
    if (($line[4]=='C') and ($line[5]!='A')) $rbg1 = "#0f0";
    if (($line[4]=='C') and ($line[5]=='A')) $rbg1 = "#f99";
    if ($line[4]=='U') $rbg1 = "#fc6";

#        if (($oldline[0]==$line[0]) and ($oldline[1]==$line[1]) and ($oldline[2]!=$line[2]))
#            $rbg = "#FFa";
#        else
#    } else {
#        $rbg1 = "#fff";
#    }



#    foreach ($line as $col_value) {
#        echo "\t\t<td><a href='?lab=$line[0]'>$line[0]</a></td>\n";
#    }
echo "<tr bgcolor='".$rbg1."'>";
echo "<td>".$line[0]."</td>";
echo "<td><a href='?sample=$line[1]'>".$line[2]."</a></td>";
echo "<td>".$line[3]."</td>";
echo "<td>".$line[4]."</td>";
echo "<td>".$line[5]."</td>";
echo "</tr>";
}
#echo "<td><a href='?lab=СХРМИ&room=ХР-221'>ХР-221</td>";
#    echo "\t</tr>\n";

echo "</table>\n";


// Очистка результата
pg_free_result($result);

echo "</td><td>";


$getsample= $_REQUEST['sample'];
preg_match ("/[a-zA-Zа-яА-Я0-9]+/msiu",$getsample,$matches);
$sample = $matches[0];



if (strlen($sample)>0) {
#echo "<p>Списываем с образца ".$sample."</p>";

#echo "<table border='1px'>\n";
#echo "<tr><td  style='vertical-align:top'>\n";




##############################
#2
#####################################
echo "<table border='1px'>\n";


$q1 = "select replace(entry,',','.')::float from result 
inner join sample on result.sample_number = sample.sample_number
where sample.sample_number = ".$sample."  and analysis like 'СОП.М.ФХ.006.%' and reportable='T' and result.status != 'X' ";
$res = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($res, null, PGSQL_NUM);
$zola = $line[0];

$q1 = "select replace(entry,',','.')::float from result 
inner join sample on result.sample_number = sample.sample_number
where sample.sample_number = ".$sample."  and analysis like 'СОП.М.ФХ.001.%' and reportable='T' and result.status != 'X' ";
$res = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($res, null, PGSQL_NUM);
$belok = $line[0];

$q1 = "select replace(entry,',','.')::float from result 
inner join sample on result.sample_number = sample.sample_number
where sample.sample_number = ".$sample."  and (analysis like 'СОП.М.ФХ.002.%' or analysis like 'СОП.М.ФХ.003.%') and reportable='T' and result.status != 'X' ";
$res = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($res, null, PGSQL_NUM);
$zhir = $line[0];

$q1 = "select replace(entry,',','.')::float from result 
inner join sample on result.sample_number = sample.sample_number
where sample.sample_number = ".$sample."  and analysis like 'СОП.М.ФХ.008.%' and reportable='T'  and result.status != 'X' ";
$res = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($res, null, PGSQL_NUM);
$vlaga = $line[0];

$q1 = "select replace(entry,',','.')::float from result 
inner join sample on result.sample_number = sample.sample_number
where sample.sample_number = ".$sample."  and analysis like 'СОП.М.ФХ.015.%' and reportable='T' and result.status != 'X' ";
$res = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($res, null, PGSQL_NUM);
$klet = $line[0];

$q1 = "select replace(entry,',','.')::float from result 
inner join sample on result.sample_number = sample.sample_number
where sample.sample_number = ".$sample."  and analysis like 'СОП.М.ФХ.043.%' and reportable='T' and result.status != 'X' ";
$res = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($res, null, PGSQL_NUM);
$pisch_volokna = $line[0];



# сахара???
$q1 = "select sum(replace(entry,',','.')::float / 10.0) from result
inner join sample on result.sample_number = sample.sample_number
inner join sample s_orig on s_orig.sample_number = sample.original_sample
inner join sample s_xp on s_orig.sample_number = s_xp.original_sample
where s_xp.sample_number = ".$sample." and analysis like 'СОП.М.ХР.029.%' and reportable='T' and result.status != 'X' ";
$res = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($res, null, PGSQL_NUM);
$sugar = $line[0];

if ($pisch_volokna)
    $klet = $pisch_volokna;



$ost = 100 - round($zhir,2) - round($belok,2) - round($vlaga,2) - round($zola,2) - round($klet,2) - round($sugar,2);




$query="select c_protocol_number,okpd,c_product.name from sample 
inner join c_product on c_product.id = sample.c_product
where sample_number = '".$sample."'";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($result, null, PGSQL_NUM);

echo "<tr><th colspan='5'>Считаем для образца ".$line[0]." [".$line[1]."] ".$line[2]."</th></tr>\n\n";
echo "<tr><td>Жир</td><td>".round($zhir,2)."</td></tr>";
echo "<tr><td>Белок</td><td>".round($belok,2)."</td></tr>";
echo "<tr><td>Влага</td><td>".round($vlaga,2)."</td></tr>";
echo "<tr><td>Зола</td><td>".round($zola,2)."</td></tr>";
echo "<tr><td>Клетчатка/пищ.волок</td><td>".round($klet,2)."</td></tr>";
echo "<tr><td>Сахара</td><td>".round($sugar,2)."</td></tr>";
echo "<tr><th>Остаток</th><th>".$ost."</th></tr>";



$query="select result.name,test.analysis,test.status,count(test.status) 
from result 
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number= test.sample_number
inner join project on project.name = sample.project
where test.status in ('A','X') and result.reportable='T' and result.displayed='T'
and test.status='notstatus'
and sample.login_date>now() - interval '6 month' and sample.original_sample!=".$sample."
and c_product = (select sample.c_product from sample 
    inner join project on project.name = sample.project
    where sample_number = ".$sample.") 
and project.customer= (select project.customer from sample 
    inner join project on project.name = sample.project
    where sample_number = ".$sample." )
group by test.lab,result.name,test.analysis,test.status
order by test.lab,result.name,test.analysis 
 " ;
#    order by test.analysis,test.reported_name ";



    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
$total=0;

#echo "<table>\n";
#while ($line = pg_fetch_array($result, null, PGSQL_NUM)) { #PGSQL_ASSOC
#    if ($line[2]=='X') {
#        if (($oldline[0]==$line[0]) and ($oldline[1]==$line[1]) and ($oldline[2]!=$line[2]))
#            $rbg = "#FFa";
#        else
#            $rbg = "#Faa";
#    } else {
#        $rbg = "#9f9";
#    }
#
#    echo '<tr bgcolor="'.$rbg.'"><td>';
#    $total = $total + 1;
#    echo $total."</td></td>";
#
#echo "<td>".$line[0]."</td>";
#echo "<td>".$line[1]."</td>";
#if ($line[2]=='A')
#    echo "<td>Авторизовано</td>";
#if ($line[2]=='X')
#    echo "<td>Отменено</td>";
#echo "<td>".$line[3]."</td>";



#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
#    echo "</tr>\n";
#    $oldline=$line;
#}
#if ($total==0) 
#    $txttotal="У этого клиента для этой матрицы за 6 месяцев нет истории испытаний. При выборе методик следует пользоваться общими правилами";
#else
#    $txttotal="Всего строк: $total";

#echo "<tr><td colspan='4'>$txttotal </td></tr>";

echo "</table>\n";


echo "\n</td>";

###################### 
?>
<td>
<table border="1px">
<tr ><th>условные обозначения для списка объектов</th></tr>
<tr bgcolor="#fc6"><td>В процессе регистрации</td></tr>
<tr bgcolor="#fff"><td>Полученные, но не начатые</td></tr>
<tr bgcolor="#3f9"><td>Начатые</td></tr>
<tr bgcolor="#0f0"><td>Завершенные</td></tr>
<tr bgcolor="#f99"><td>Реактивироанные</td></tr>

<tr ><th>условные обозначения для анализов</th></tr>
<tr bgcolor="#9f9"><td>Авторизованные тесты</td></tr>
<tr bgcolor="#FFA"><td>Отмененные тесты при наличии таких-же авторизованных</td></tr>
<tr bgcolor="#FAA"><td>Только отмененные тесты</td></tr>
</table>
<p>Сервис делает выборку законченых тестов для выбранного образца и того-же клиента</p>
<p>Отсутствие рекомендации говорит или о новом клиенте или о нетипичной матрице</p>
<p>Зеленый фон говорит о том, что этот клиент в этом образце уже заказывал этот тест и он был авторизован. <br>Стандартая ситуация</p>
<p>Желтый фон говорит о том, что этот клиент в этом образце уже заказывал этот тест но несколько из них были отменены. <br>Бывает в случае автоотмены теста или лишнего назначения правильного теста.</p>
<p>Красный фон говорит о том, что все такие тесты для этого клиент в этом образце были отменены. <br>Чаще всего бывает при неправильно назначенных тестах.</p>



</td></tr>
<?php

echo "</table>\n";


#echo "</td></tr></table>";
// Очистка результата
pg_free_result($result);
}


// Закрытие соединения
pg_close($dbconn);
?>
</body>
</html>