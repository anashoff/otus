<?php

#include "auth.php";
// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");
// Преобразование массива чисел в интервалы
function array_to_intervals($data=array(), $divider='-') {
        // Оставить только уникальные значения
        $data=array_unique($data);
        sort($data);
     
        $tmp=array();
        $begin=$end=0;
     
        for ($i=0; $i<count($data); $i++) {
            // Начало интервала или одиночное значение
            if ($begin==0) {
                $begin=$end=$data[$i];
            }
     
            if (isset($data[($i+1)])) {
                // Расширить границы интервала
                if ($data[($i+1)]==($end+1)) {
                    $end++;
                }
                else {
                    // Одиночное значение
                    if ($begin==$end) {
                        $tmp[]=$begin;
                    }
                    // Интервал
                    else {
                        $tmp[]=$begin.$divider.$end;
                    }
                    $begin=$end=0;
                }
            }
        }
     
        if (count($data)) {
            // Последнее значение
            if ($begin==$end) {
                $tmp[]=$begin;
            }
            else {
                $tmp[]=$begin.$divider.$end;
            }
        }
        return implode(', ',$tmp);
    }



function serial_number($arrpr) {
#$arrpr = ["10001-21","10003-21","10005-21","10006-21","10007-21","10008-21","10009-21","10010-21","10011-21","10012-21"];
print_r($arrpr);
$totalpr = "";
$maxcount = count($arrpr);
$serial = false;
$totalpr = "";
$startpr = "";#$arrpr[0];
$endpr = "";


for ($i = 0; $i < $maxcount; $i++) {
#    echo $i.". ".$arrpr[$i]."| ".$startpr."/".$endpr."<br>";
        $lpr = (int)substr($arrpr[$i],0,-3);
        $rpr = (int)substr($arrpr[$i+1],0,-3);

    if ( $startpr == "")
            $startpr =  $lpr; #$arrpr[$i];
    if ($i + 1 < $maxcount-1) {

#            echo $arrpr[$i]."=>".$lpr."<>".$rpr."<br>";

        if ($rpr == $lpr+1) {
            $serial = true;
            $endpr = $lpr; # $arrpr[$i];

        } else {
            if ($serial == false) # startpr != "" and $endpr != "") 
                $totalpr = $totalpr.$lpr.", "; #$arrpr[$i]
            else {
                $totalpr = $totalpr.$startpr."—".$lpr.", "; #;$arrpr[$i]
                }
            $startpr = ""; #$arrpr[$i];
            $serial = false;
            $endpr = "";
        }
    }
}
$totalpr = $totalpr.$startpr."—".$endpr."";

return $totalpr;

}

$column3 = [
#    "№"=>"nn",
#    "НД"=>"full_name",
    "Название образца"=>"product",
    "показатель"=>"resultname",
    "количество образцов"=>"samplecount",
    "номер образца"=>"c_protocol_number",

#    "Отчетное значение"=>"protocol_value",
    "МБ задание"=>"protocol_unit",
    "отметка"=>"",
#    "МБ"=>"protocol_comment_value",
#    "МБ ЕИ"=>"protocol_comment_unit",
#    ""=>"",
];

$column = [
#    "№"=>"nn",
#    "НД"=>"full_name",
    "Название образца"=>"product",
#    "показатели"=>"nds",
#    "количество образцов"=>"samplecount",
    "номера образцов"=>"c_protocol_numbers",

#    "Отчетное значение"=>"protocol_value",
#    "МБ задание"=>"protocol_unit",
    "отметка"=>"",
#    "МБ"=>"protocol_comment_value",
#    "МБ ЕИ"=>"protocol_comment_unit",
#    ""=>"",
];




$column_main = [
    "№"=>"nn",
    "Проект"=>"name",
    "Количество образцов"=>"count_sample",
#    "заказчик"=>"customer",
    "дата регистрации"=>"date_created",
    "ГПП"=>"created_by",
    "Статус"=>"status"

];




if (isset($_REQUEST['project'])) {
    $project = pg_escape_string($_REQUEST['project']);

$query1 = "select
--case when c_metodics.indicator_synonym is null then c_indicator.name1 else c_metodics.indicator_synonym end as name,
--    t_analysis_method.full_name,
--    row_number() OVER(order by result.name,sample.c_protocol_number) as nn,
distinct(case when sample.c_protocol_number like '%-21%' then left(sample.c_protocol_number,length(sample.c_protocol_number)-3) else sample.c_protocol_number end) as c_protocol_number
--    sample.sample_name,
--    result.protocol_value,
--    result.protocol_comment_value,
--    result.protocol_comment_unit,
--case when result.protocol_comment_unit is not null then 'в ' || (case when result.protocol_comment_value  is not null then (result.protocol_comment_value ||' ') else '' end) ||  u2.display_string else u1.display_string  end as protocol_unit,
--    test.c_external_doc 
from result
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number = test.sample_number
inner join t_analysis_method on t_analysis_method.name = test.c_external_doc
inner join c_metodics on c_metodics.code = result.c_metodic_code
inner join c_indicator on c_indicator.name = c_metodics.indicator
left outer join units u1 on u1.unit_code =  result.protocol_unit
left outer join units u2 on u2.unit_code =  result.protocol_comment_unit

where sample.project ='".$project."' and result.c_metodic_code is not null
and sample.lab='СМБМИ'
and sample.status != 'X' and test.status != 'X' and result.status != 'X'
order by --test.lab,result.name,t_analysis_method.full_name,sample.
c_protocol_number";



$query2 = "select 
case when c_metodics.indicator_synonym is null then c_indicator.name1 else c_metodics.indicator_synonym end as name,
    t_analysis_method.full_name,
    row_number() OVER(order by result.name,sample.c_protocol_number) as nn,
case when sample.c_protocol_number like '%-21%' then sample.c_protocol_number else sample.c_protocol_number || '-21' end as c_protocol_number,
--    sample.sample_name,
    result.protocol_value,
    result.protocol_comment_value,
    result.protocol_comment_unit,
case when result.protocol_comment_unit is not null then 'в ' || (case when result.protocol_comment_value  is not null then (result.protocol_comment_value ||' ') else '' end) ||  u2.display_string else u1.display_string  end as protocol_unit,
    test.c_external_doc 
from result
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number = test.sample_number
inner join t_analysis_method on t_analysis_method.name = test.c_external_doc
inner join c_metodics on c_metodics.code = result.c_metodic_code
inner join c_indicator on c_indicator.name = c_metodics.indicator
left outer join units u1 on u1.unit_code =  result.protocol_unit
left outer join units u2 on u2.unit_code =  result.protocol_comment_unit

where sample.project ='".$project."' and result.c_metodic_code is not null
and sample.lab='СМБМИ'
and sample.status != 'X' and test.status != 'X' and result.status != 'X'
order by test.lab,result.name,t_analysis_method.full_name,sample.c_protocol_number";


#группировка для микробиологии
$query3 = "
select (c_product.okpd||' '||c_product.name) as product, case when c_metodics.indicator_synonym is null then c_indicator.name1 else c_metodics.indicator_synonym end as resultname,
    t_analysis_method.full_name,
    -- row_number() OVER(order by result.name,sample.c_protocol_number) as nn,
string_agg(case when sample.c_protocol_number like '%-21%' then sample.c_protocol_number else sample.c_protocol_number || '-21' end,', ' order by c_protocol_number) as c_protocol_number,
count(sample.c_protocol_number) as samplecount,
--    sample.sample_name,
    --result.protocol_value,
    --result.protocol_comment_value,
    --result.protocol_comment_unit,
(case when result.protocol_comment_unit is not null then 'в ' 
    || (case when result.protocol_comment_value  is not null then (result.protocol_comment_value ||' ') else '' end) 
        ||  u2.display_string || ' (' || case when u3.display_string = '-' then 'Обнаружение' else u3.display_string end || ')'  else u3.display_string  end) as protocol_unit,
    test.c_external_doc 
from result
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number = test.sample_number
inner join t_analysis_method on t_analysis_method.name = test.c_external_doc
inner join c_metodics on c_metodics.code = result.c_metodic_code
inner join c_indicator on c_indicator.name = c_metodics.indicator
inner join c_product on c_product.id = sample.c_product
left outer join units u1 on u1.unit_code =  result.protocol_unit
left outer join units u2 on u2.unit_code =  result.protocol_comment_unit
inner join units u3 on u3.unit_code =  result.units
where sample.project ='".$project."' and result.c_metodic_code is not null
and sample.lab='СМБМИ'
and sample.status != 'X' and test.status != 'X' and result.status != 'X'
group by  c_product.okpd, c_product.name, resultname, t_analysis_method.full_name, result.protocol_comment_unit, result.protocol_comment_value,  u2.display_string, --u1.display_string,
test.c_external_doc,u3.display_string 

order by resultname,t_analysis_method.full_name
";


$query4 = "select product,nds,string_agg(case when c_protocol_number like '%-21%' then left(c_protocol_number,length(c_protocol_number)-3) else c_protocol_number end,', ' order by c_protocol_number) as c_protocol_numbers from (
select product,c_protocol_number,string_agg(maxconcat,'^' order by maxconcat) as nds from (
select (c_product.okpd||' '||c_product.name) as product,  
case when c_metodics.indicator_synonym is null then c_indicator.name1 else c_metodics.indicator_synonym end  || ' ' ||  
    test.c_external_doc || ' ' || 
    (case when result.protocol_comment_unit is not null then 'в '
    || (case when result.protocol_comment_value  is not null then (result.protocol_comment_value ||' ') else '' end)
        ||  u2.display_string || ' (' || case when u3.display_string = '-' then 'Обнаружение' else u3.display_string end || ')'  else u3.display_string  end) 	
    as maxconcat,
    sample.c_protocol_number
   
from result
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number = test.sample_number
inner join t_analysis_method on t_analysis_method.name = test.c_external_doc
inner join c_metodics on c_metodics.code = result.c_metodic_code
inner join c_indicator on c_indicator.name = c_metodics.indicator
inner join c_product on c_product.id = sample.c_product
left outer join units u1 on u1.unit_code =  result.protocol_unit
left outer join units u2 on u2.unit_code =  result.protocol_comment_unit
inner join units u3 on u3.unit_code =  result.units
where sample.project ='".$project."' and result.c_metodic_code is not null
and sample.lab='СМБМИ'
and sample.status != 'X' and test.status != 'X' and result.status != 'X'
--group by sample.c_protocol_number
--group by  c_product.okpd, c_product.name, resultname, t_analysis_method.full_name, result.protocol_comment_unit, result.protocol_comment_value,  u2.display_string, --u1.display_string, 
--test.c_external_doc,u3.display_string
order by sample.c_protocol_number,test.analysis ) as step1--resultname,t_analysis_method.full_name
group by product,c_protocol_number) as step2
group by product,nds

";


$result = pg_query($query1) or die('Ошибка запроса: ' . pg_last_error());

$qbarcode = "select max(sample_number)-min(sample_number),count(sample_number),to_char(min(login_date),'DD/MM/YYYY') from sample where project = '".$project."' and parent_aliquot=0  and status != 'X' ";
$resbarcode = pg_query($qbarcode) or die('Ошибка запроса: ' . pg_last_error());
$linebarcode = pg_fetch_array($resbarcode, null);
$barcode = $project."+".$linebarcode[0]."%".$linebarcode[1];


$arrpr = [];
while ($line0 = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
$arrpr[]= $line0['c_protocol_number'];
}

#$arrpr = ["10001-21","10003-21","10005-21","10006-21","10007-21","10008-21","10009-21","10010-21","10011-21","10012-21"];

$totalpr = "";
$maxcount = count($arrpr);
$serial = false;
$totalpr = "";
$startpr = "";#$arrpr[0];
$endpr = "";


for ($i = 0; $i < $maxcount; $i++) {
#    echo $i.". ".$arrpr[$i]."| ".$startpr."/".$endpr."<br>";
        $lpr = (int)substr($arrpr[$i],0,-3);
        $rpr = (int)substr($arrpr[$i+1],0,-3);

    if ( $startpr == "")
            $startpr =  $lpr; #$arrpr[$i];
    if ($i + 1 < $maxcount-1) {

#            echo $arrpr[$i]."=>".$lpr."<>".$rpr."<br>";

        if ($rpr == $lpr+1) {
            $serial = true;
            $endpr = $lpr; # $arrpr[$i];

        } else {
            if ($serial == false) # startpr != "" and $endpr != "") 
                $totalpr = $totalpr.$lpr.", "; #$arrpr[$i]
            else {
                $totalpr = $totalpr.$startpr."—".$lpr.", "; #;$arrpr[$i]
                }
            $startpr = ""; #$arrpr[$i];
            $serial = false;
            $endpr = "";
        }
    }
}
$totalpr2 = $totalpr.$startpr."—".$endpr."";

$totalpr = array_to_intervals($arrpr);

#exit(0);
#$totalpr = "";
#$startpr = "";
#$endpr = "";
#$oldnm=0;
#$serial = false;

#while ($line0 = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
#  $newnm = (int)substr($line0['c_protocol_number'],0,-3);
#$endpr = $line0['c_protocol_number'];
#echo $endpr."<br>";

#if ($newnm > $oldnm) {
#    if ($oldnm == 0) {
#        $oldnm = $newnm;
#        $startpr = $line0['c_protocol_number'];
#        $endpr = $line0['c_protocol_number'];
#    }
#    if ($newnm == $oldnm+1) #номера подряд
#        {
#        $serial = true;
#        $endpr = $line0['c_protocol_number'];
#        if ($startpr == "") 
#            $startpr = $line0['c_protocol_number'];
#        }
#    else #номера не подряд
#        {
#        echo $line0['c_protocol_number']."<br>";
#        $endpr = $line0['c_protocol_number'];

#            if ($serial == false ) {
#                $totalpr = $totalpr." ".$endpr.", ";
#                echo $line0['c_protocol_number']." " .$startpr."/ ".$endpr.$serial."<br>";
#                }
#            if ($serial == true )
#                $totalpr = $totalpr." ".$startpr." - ".$endpr.", ";
#            $serial = false;
#            $startpr = $line0['c_protocol_number'];
#            $endpr = ""; #$line0['c_protocol_number'];
#           $oldnm = 0;

#            $startpr = "";
#           $endpr = "";
#            $oldnm=0;
#        }
#}
#$oldnm = $newnm;
#}
#$totalpr = $totalpr." ".$startpr." - ".$endpr.", ";




############################# html

?>
<a href='lzd.php'>Главный список</a>
<p></p>
<table cellspacing="0" border="1" cellpadding="10" width="800">
<tr>
<td width="33%">Дата начала испытания:</td>
<td  width="33%">Исполнитель:</td>
<td width="33%">Лаб №№ проб:</td>
</tr>

<table cellspacing="0" border="1" cellpadding="10" width="800">
<tr>
<td width="25%">Дата регистрации</td>
<td width="25%"><b><?php echo $linebarcode[2];?></b></td>
<td width="25%">Шифр пробы</td>
<td width="25%"><b><?php echo $totalpr;?></b></td>
</tr>
</table>

<table>


<?php
###################################### html

echo '<p><font face="code39azaleanarrow3" style ="font-size: 64px;">*'.$barcode."*</font></p>";

echo "<table>";
$olg_name = '';
$result = pg_query($query4) or die('Ошибка запроса: ' . pg_last_error());
while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
    if ($old_name != $line['nds'] ) {
        echo "</table></br><table border='1'><tr>\n";
	
        echo "<tr><th colspan='5' align='left'>".str_replace('^','<br>',$line['nds'])."</th></tr>";
        foreach ($column as $key=>$one)
            echo "<th>".$key."</th>";
        echo "</tr>";
    $old_name = $line['nds'];
}


$sc = "white";
if ($line["status"]=='A')
    $sc = "MediumSeaGreen";
if ($line["status"]=='X')
    $sc = "Dimgray";
if ($line["status"]=='N')
    $sc = "Tomato";

#----

echo "<tr style = 'background-color:".$sc."'>";

    echo  "<td>".$line['product']."</td>";


#foreach ($column as $one) {

#    echo "<td>";
#    echo $line[$one];
#    echo "</td>";
#}
#echo "<td>".serial_number(explode(', ',$line['c_protocol_numbers']))."</td>";
echo "<td>".array_to_intervals(explode(', ',$line['c_protocol_numbers']))."</td>";
    echo  "<td> </td>";

}

} else
{

$query_main = "select project.name,project.customer,project.date_created,project.created_by,project.status,
count(sample_number) as count_sample, row_number() OVER(order by name) as nn from sample
inner join project on project.name = sample.project
where closed ='F' and project.status not in ('X') and sample.parent_aliquot=0 and sample.status!='X'
and sample.lab = 'СМБМИ'
group by  project.name,project.customer,project.date_created,project.created_by,project.status
--having count(sample_number) > 1
order by name
";


$result_main = pg_query($query_main) or die('Ошибка запроса: ' . pg_last_error());
echo "список открытых проектов где есть микробиолгия";


echo "<table border='1' id='protocol_table'>";
foreach ($column_main as $key=>$one)
    echo "<th>".$key."</th>";

while ($line = pg_fetch_array($result_main, null,  PGSQL_ASSOC)) {
$sc = "white";
if ($line["status"]=='V')
    $sc = "MediumSeaGreen";
if ($line["status"]=='X')
    $sc = "Dimgray";
if ($line["status"]=='N')
    $sc = "Tomato";

#----
echo "<tr style = 'background-color:".$sc."'>";
foreach ($column_main as $one) {

echo "<td>";
    if ($one=='name')
        echo '<a href="lzd.php?project='.$line[$one].'">'.$line[$one].'</a>';
    else
        echo $line[$one];
echo "</td>";
}

}



}
