<?php
$ip = array(
"192.168.50.102", #developer
"192.168.50.28", #k1
"192.168.50.29", #k2
"192.168.50.30", #k3
"192.168.50.22", #NE
"192.168.50.82", #valentina wifi
"192.168.50.83", #valentina lan
"192.168.50.121", #feilx lan
"192.168.50.131", #feilx vpn
"192.168.50.1", #router
"192.168.50.93", #valentina lan2
"192.168.50.131" #felix vpn

);

if (!in_array($_SERVER['REMOTE_ADDR'], $ip)) {
echo "FGIS for ".$_SERVER['REMOTE_ADDR'];
exit(0);
}
#if ($_SERVER['REMOTE_ADDR']=="192.168.50.101") {
#
#
#echo "fgis";
#exit(0);
#}




// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.50.251 dbname=LIMS_PUSCHINO_DEV user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


# ajax1
if (isset($_REQUEST['term'])) {
$getorg = $_REQUEST['term'];

preg_match ("/[a-zA-Zа-яА-Я ]+/msiu",$getorg,$matches);
#print_r ($matches);
$org = $matches[0];
$org = pg_escape_string ( $_REQUEST['term'] );
// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select org,inn from fgis2inn where org ilike '%$org%' order by org_order desc limit 20";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
$arr = array(); 

#$result = exec('grep  -iF "'.$org.'" kmapojolnaewrgf.php ',$arr); 
#echo 'grep -i "'.$org.'" kmapojolnaewrgf.php';


// Generate array with skills data 
$orgData = array(); 
$id=1;


while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {
    $data['id']=$id;
    $data['value']=$line[0];
    $data['inn']=$line[1];
    array_push($orgData,$data);
    $id +=1 ;
}
echo json_encode($orgData); 
exit(0);
}
### end ajax1

# ajax2
if ((isset($_REQUEST['read'])) or (isset($_REQUEST['read2']))) {

#read	14.08.2019
#id	191
#comm	remove
    if (  (isset($_REQUEST['id'])) and (isset($_REQUEST['comm']))) {
        if ($_REQUEST['comm']=='remove') {
            $query = "update fgis2 set removed='T' where id = ".pg_escape_string($_REQUEST['id']);
            $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
        }

        if ($_REQUEST['comm']=='recover') {
            $query = "update fgis2 set removed='F' where id = ".pg_escape_string($_REQUEST['id']);
            $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
        }

}



    $read_data = $_REQUEST['read'];
    $read_data2 = $_REQUEST['read2'];
    if (strlen($read_data2)>8) {
        echo "ошибка, номер протокола не может быть больше 8 символов";
#        echo strlen($read_data2);
        exit(0);
    }

    if ((isset($_REQUEST['read']) and (strlen($read_data)!=10))) {
        echo "ошибка, ошибка в формате даты ";
#        echo strlen($read_data2);
        exit(0);
    }

if (isset($_REQUEST['read'])) {
    $query = "select *,(select count(protocol_number) from fgis2 f2 where f2.protocol_number= fgis2.protocol_number) as co from fgis2 where create_data::date  = '$read_data' order by id"; #id org_name
    }
if (isset($_REQUEST['read2']))
    $query = "select * from fgis2 where protocol_number  like '$read_data2%' and create_data > now() - interval '6 month'  order by id limit 100";

$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Generate array with skills data 
$orgData = array(); 
$id=1;


echo "<table border='1' id='fgis_table'>";
echo "<tr>
<th>Номер записи</th>
<th>Номер протокола</th>
<th>Дата протокола</th>
<th>Место испытаний</th>
<th>Заявитель</th>
<th>ИНН</th>
<th>Полное наименование образца</th>
<th>Дата получения образца</th>
<th>Дата внесенния в спиcок</th>
<th>Адрес внесения</th>
</tr>";
while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
    if ($line[removed]=='T') {
        $re="re";
#        echo '<tr class="re">'; 
    } else {
        $re="nre";
#        echo "<tr>"; 
    }
#    id, protocol_number, protocol_data, address, org_name, org_inn, obj_name, obj_data, create_data, create_ip)

    if ($line['co']>1) {
        $co=' style="background-color:orange" ';
    } else {
        $co="";
    }



    echo "
<tr $co>
<td >".$line['id']."</td>
<td class='$re'>".$line['protocol_number']."</td>
<td class='$re'>".$line['protocol_data']."</td>
<td class='$re'>".$line['address']."</td>
<td class='$re'>".$line['org_name']."</td>
<td class='$re'>".$line['org_inn']."</td>
<td class='$re'>".$line['obj_name']."</td>
<td class='$re'>".$line['obj_data']."</td>
<td class='$re'>".$line['create_data']."</td>
<td class='$re'>".$line['create_ip']."</td>
";
    if ($line[removed]=='T') {
        echo '<td><input onclick="re_nre('.$line[id].', \'recover\')" type="button" value="восстановить"></td>'; 
    } else {
        echo '<td><input onclick="re_nre('.$line[id].', \'remove\')" type="button" value="удалить"></td>'; 
#        echo "<td>удалить</td>"; 

    }


    echo "</tr>";

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
#echo $line;
#    $data['id']=$id;
#    $data['value']=$line[0];
#    $data['inn']=$line[1];
#    array_push($orgData,$data);
#    $id +=1 ;
}
echo "</table>";
#echo json_encode($orgData); 
exit(0);
}
### end ajax1


### post
#Array
#(
#    [number_protocol] => 123
#    [date_protocol] => 11.08.2019
#    [place] => Корпус Б
#    [org_input] => ООО «ЭкоНиваАгро»
#    [org_inn] => 1234567890
#    [full_object] => йф2й
#    [date_object] => 29.08.2019
#    [submit] => Отправить
#)
#192.168.50.102

#INSERT INTO public.fgis2(
#    id, protocol_number, protocol_data, address, org_name, org_inn, obj_name, obj_data, create_data, create_ip)
#    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);


 if  ( $_SERVER['REQUEST_METHOD'] == "POST"){
#        print_r($_POST);
#        echo $_SERVER['REMOTE_ADDR'];
#    $ins=array();
#    $ind['id']='';
#    $ins['protocol_number'] =  $_POST['protocol_number'];
#    $ins['protocol_data'] =$_POST['protocol_data'];
#    $ins['address']=$_POST['address'];
#    $ins['org_name']=$_POST['org_name'];
#    $ins['org_inn']= $_POST['org_inn'];
#    $ins['obj_name'] = $_POST['obj_name'];
#    $ins['obj_data'] = $_POST['obj_data'];
#    $ins['create_data'] = date("d.m.Y");
#    $ins['create_ip'] =  $_SERVER['REMOTE_ADDR'];

#        print_r($_POST);
#        print_r($ins);

$query = "INSERT INTO public.fgis2(
    protocol_number, protocol_data, address, org_name,  org_inn, obj_name, obj_data, create_ip)  VALUES 
('".pg_escape_string ( $_POST['protocol_number']). "', '".pg_escape_string ($_POST['protocol_data'])."', '".pg_escape_string ($_POST['address'])."', 
'".pg_escape_string ($_POST['org_name'])."', '".pg_escape_string ($_POST['org_inn'])."', '".pg_escape_string ($_POST['obj_name'])."', 
'".pg_escape_string ($_POST['obj_data'])."', '".$_SERVER['REMOTE_ADDR']."');";
#echo $query;
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
if ($result) {
    echo "<b>запись успешно добавлена</b>";
 } else {
    echo "ошибка пори добавлении данных";
}




#  $res = pg_insert($dbconn, 'fgis2', $ins);
#    echo "res start";
#    print_r($res);
#    echo pg_last_error();
#    echo pg_result_error ($res);
#    echo "res end";
#  if ($res) {
#      echo "Данные из POST успешно внесены в журнал\n";
# } else {
#      echo "Пользователь прислал неверные данные\n";
#  }




}
#echo $_SERVER['REQUEST_METHOD'];
#exit(0);



###end post




?>


<html>
<head>
<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- jQuery UI library -->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
<script src="datepicker-ru.js"></script>
<script src="jquery.validate.js"></script>
<script src="messages_ru.js"></script>
<link rel="stylesheet" type="text/css" href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">
<script type="text/javascript" src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

<title>2ФГИС</title>
</head>

<style>
.error {color:red;}
.re {text-decoration: line-through;}
.nre {text-decoration: none;}
.ttable td{vertical-align: top;}
</style>

<script>
$(function() {
    $.datepicker.setDefaults( $.datepicker.regional[ "ru" ] );
    $("#org_name").autocomplete({
        source: "fgis_2.php",
    select: function (event, ui) {
            $( "#org_name" ).val( ui.item.value );
            $( "#org_inn" ).val( ui.item.inn );
            return false;
        }
    });
    $( "#org_name" ).keyup(function() {
      $( "#org_inn" ).val("" );
    });
    $('#fgis_table').DataTable();


    $( "#read" ).change(function() {
//      alert( $( "#read" ).val( ));
      $( "#read2" ).val("" );
    $.get("fgis_2.php", { read: $( "#read" ).val( ) })
        .done(function(data) {
         $("#protocols").html( data );

        $('#example').DataTable({  
            "ajax" : data
            });
        });
    });

    $( "#read2" ).keyup(function() {
//      alert( $( "#read" ).val( ));
      $( "#read" ).val("" );
    $.get("fgis_2.php", { read2: $( "#read2" ).val( ) })
        .done(function(data) {
         $("#protocols").html( data );

        $('#example').DataTable({  
            "ajax" : data
            });
        });
    });

 

    $( "#read" ).datepicker( );

    $( "#protocol_data" ).datepicker( );
    $( "#obj_data" ).datepicker( );
    $( "#mainForm" ).validate();

	$.validator.messages.required = " << Заполните поле!";
	$.validator.messages.email = "Неверный формат email";
	$.validator.messages.url = "Неверный формат url, начните с http://";

});

    function re_nre(re_id, comm) {
//    alert(re_id);
//    alert(comm);

//      alert( $( this ).parent().html() );
    $.get("fgis_2.php", { 
            read: $( "#read" ).val( ),
            id: re_id,
            comm: comm

            })
        .done(function(data) {
         $("#protocols").html( data );
        });
    };
    function fgis(number,p_date,house,customer,inn,name,recd_date) {
//	alert($(this).parent().val());
	row = $(event.target).parent().parent().children();
        room = $(row[3]).html();
        if (room=="Б") {
        $("#address").val("Корпус Б");
        }else if(room=="В"){
        $("#address").val("Корпус В");
        }else{
        $("#address").val("Оба корпуса");
        }



                
        $("#protocol_number").val($(row[1]).html());
        $("#protocol_data").val($(row[2]).html());
        $("#org_name").val($(row[4]).html());
        $("#org_inn").val($(row[5]).html());
        $("#obj_name").val($(row[6]).html());
        $("#obj_data").val($(row[7]).html());
    };
</script>

<script>
document.addEventListener('DOMContentLoaded', () => {

    const getSort = ({ target }) => {
        const order = (target.dataset.order = -(target.dataset.order || -1));
        const index = [...target.parentNode.cells].indexOf(target);
        const collator = new Intl.Collator(['en', 'ru'], { numeric: true });
        const comparator = (index, order) => (a, b) => order * collator.compare(
            a.children[index].innerHTML,
            b.children[index].innerHTML
        );
        
        for(const tBody of target.closest('table').tBodies)
            tBody.append(...[...tBody.rows].sort(comparator(index, order)));

        for(const cell of target.parentNode.cells)
            cell.classList.toggle('sorted', cell === target);
    };
    
    document.querySelectorAll('.table_sort thead').forEach(tableTH => tableTH.addEventListener('click', () => getSort(event)));
    
});
</script>


<h1>подготовка информации для ФГИС (v.3.2. от 15.01.2021)</h2>

<table class="ttable">
<tr><td>
<h3>Внесение новых записейдля передачи ФГИС</h3>
<form method="post" id="mainForm">
<table border="1">

<tr>
<td>Номер протокола</td>
<td><input class="required"  type="text" name="protocol_number" id="protocol_number" size="45" > </td>
</tr>



<tr>
<td>Дата протокола</td>
<td><input  class="required"  type="text" name="protocol_data" id="protocol_data" size="45"> </td>
</tr>

<tr>
<td>адрес проведения испытаний</td>
<td>
<select class="required" name="address" id="address">
    <option></option>
    <option value="Корпус Б">Корпус Б</option>
    <option value="Корпус В">Корпус В</option>
    <option value="Оба корпуса">Оба корпуса</option>
   </select>
</td>
</tr>

<tr>
<td>Полное наименование заявителя:</td>
<td><input  class="required" type="text" name="org_name" id="org_name" size="45"/></td>
</tr>
<tr>
<td>ИНН заявителя:</td>
<td><input type="text" name="org_inn" id="org_inn" size="45" readonly/></td>
</tr>

<tr>
<td>Полное наименование объекта</td>
<td><textarea  class="required" rows="10" cols="45" name="obj_name" id="obj_name"></textarea>
</tr>

<tr>
<td>Дата получения образца</td>
<td><input  class="required" type="text" name="obj_data" id="obj_data" size="45">  </td>
</tr>

<tr>
<td></td>
<td></td>
</tr>
<tr>
<td><input type="submit" name="submit" value="Отправить"/></td>
</tr>
</table>
</form>

</td><td>
<h3>Сверка ЛИМС и таблицы ФГИС</h3>
<?php 
$lost="select s.sample_number as id,s.c_protocol_number,cu.company_name,cu.c_inn,s.sample_name,concat(to_char(project.c_receipt_date::timestamp,'DD.MM.YYYY')) as recd_date,
 --to_char(s.recd_date::timestamp,'DD.MM.YYYY') as recd_date,
s.project,r.purpose,to_char(r.date_created,'DD.MM.YYYY') as protocol_data,
(select count(protocol_number) from fgis2 f2 where f2.protocol_number= s.c_protocol_number) as co2
from sample s 
inner join report_objects ro on ro.object_id = s.sample_number or ro.object_name = s.project 
inner join reports r on r.report_number = ro.report_number 
inner join project on project.name=s.project
inner join customer cu on cu.name=project.customer
where s.parent_aliquot = 0 and s.status not in ('X','U','I') 
and s.date_completed > now() - interval '28 day' 
and r.c_in_accreditation='T'
and regexp_replace(s.c_protocol_number, E'[\n\r\f\u000B\u0085\u2028\u2029]+', '', 'g' ) not in (select replace(protocol_number,'И','') from fgis2 where create_data > now() - interval '180 day' and removed!='T' ) 
order by s.c_protocol_number";



echo "<table border='1' id='lims_table'>";
echo "<tr>
<th>№</th>
<th>Номер протокола</th>
<th>Дата протокола</th>
<th>Место испытаний</th>
<th>Заявитель</th>
<th>ИНН</th>
<th>Полное наименование образца</th>
<th>Дата получения образца</th>
<th>Деуйствие</th>
</tr>";
$lost_result = pg_query($lost) or die('Ошибка запроса: ' . pg_last_error());
$lost_count= pg_num_rows($lost_result);

$n=0;
while ($line2 = pg_fetch_array($lost_result, null,  PGSQL_ASSOC)) {


$qAddr = "select string_agg(distinct(substring(test.test_location from 1 for 1)),'') as address
from project inner join sample on sample.project=project.name 
inner join test on test.sample_number=sample.sample_number 
inner join c_metodics on test.c_metodic_code=c_metodics.code 
inner join versions on versions.name=c_metodics.code and versions.table_name='C_METODICS' and c_metodics.version=versions.version 
inner join result on result.test_number=test.test_number 
where project.name = '" . $line2['project'] . "' and result.protocol_type = 'Y' 
and c_metodics.in_accreditation = 'T'
and sample.original_sample=" . $line2['id'] . " and test.status='A'";

$qHouse = pg_query($qAddr) or die('Ошибка запроса: ' . pg_last_error());
$house = pg_fetch_array($qHouse, null,  PGSQL_ASSOC);

$n += 1;

#    if ($n>120) {
#     echo '<tr><td colspan="9"><b>Показано 120 из '.$lost_count."</b></td></tr>";
#        break;
#    }


    if ($line2['c_protocol_number'] != $old_c_protocol) {
        if ($col_bg2 == "")
            $col_bg2 =' style="background-color:#999" ';
        else 
            $col_bg2="";
    }
    $old_c_protocol =  $line2['c_protocol_number'];


    if ($line2['co']>1) 
        $col_bg = ' style="background-color:orange" ';



    echo "
<tr ".$col_bg.">
<td >".$n."</td>
<td  ".$col_bg2.">".$line2['c_protocol_number']."</td>
<td >".$line2['protocol_data']."</td>
<td >".$house['address']."</td>
<td >".$line2['company_name']."</td>
<td >".$line2['c_inn']."</td>
<td >".$line2['sample_name']."</td>
<td >".$line2['recd_date']."</td>
<td><input onclick=\"fgis()\"".
#.$line2[c_protocol_number]."','"
#.$line2[protocol_data]." ','"
#.$house[address]."','"
#.addslashes($line2[company_name])."','"
#.$line2[c_inn]."','"
#.addslashes($line2[sample_name])."','"
#.$line2[recd_date]."')\" 
"
type=\"button\" value=\"Внести\"></td>
</tr>
";

}


echo "</table>";
?>
</td></tr></table>


<table border="1ps">
<tr><td  colspan="2"><h2>чтение</h2></td></tr>
<tr><td>Поиск по дате<input type="text" name="read" id="read" size="45" /></td><td>Поиск по номеру<input type="text" name="read2" id="read2" size="45" /></td> </tr>
<tr><td colspan="2"  id="protocols"><br></td></tr>
</table>

</html>