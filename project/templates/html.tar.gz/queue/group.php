  <head>
      <link rel="stylesheet" href="../css/table.css"> <!-- Путь к CSS файлу -->
  </head>


<?php
#include "auth.php";
// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


$column = [
    "№"=>"nn",
#    "НД"=>"full_name",

    "номер образца"=>"c_protocol_number",
    "Название образца"=>"sample_name",
#    "показатель"=>"name",
    "Отчетное значение"=>"protocol_value",
    "отчетная ЕИ"=>"protocol_unit",
#    "МБ значение"=>"protocol_comment_value",
#    "МБ ЕИ"=>"protocol_comment_unit",
#    ""=>"",
];

$column_main = [
    "№"=>"nn",
    "Проект"=>"name",
    "Количество образцов"=>"count_sample",
    "заказчик"=>"customer",
    "дата регистрации"=>"date_created",
    "ГПП"=>"created_by",
    "Статус"=>"status"

];




if (isset($_REQUEST['project'])) {
    $project = pg_escape_string($_REQUEST['project']);

$query = "select 
case when c_metodics.indicator_synonym is null then c_indicator.name1 else c_metodics.indicator_synonym end as name,
    t_analysis_method.full_name,
    row_number() OVER(order by result.name,sample.c_protocol_number) as nn,
case when sample.c_protocol_number like '%-22%' then sample.c_protocol_number else sample.c_protocol_number || '-22' end as c_protocol_number,
    sample.sample_name,
    result.protocol_value,
case when result.protocol_comment_unit is not null then 'в ' || (case when result.protocol_comment_value  is not null then (result.protocol_comment_value ||' ') else '' end) ||  u2.display_string else u1.display_string  end as protocol_unit,
    test.c_external_doc 
from result
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number = test.sample_number
inner join c_metodics on c_metodics.code = result.c_metodic_code
inner join t_analysis_method on t_analysis_method.name = c_metodics.external_doc
inner join c_indicator on c_indicator.name = c_metodics.indicator
left outer join units u1 on u1.unit_code =  result.protocol_unit
left outer join units u2 on u2.unit_code =  result.protocol_comment_unit

where sample.project ='".$project."' and result.c_metodic_code is not null


and test.status='A' and result.status='A' and sample.status='A'
order by test.lab,result.name,t_analysis_method.full_name,sample.c_protocol_number";

$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
echo "<table border='1px'>";
echo "<tr>";
echo "<td><a href='/' class=button-style> Главная </td>";
echo "</tr>";
echo "</table>";


echo "<a href='group.php'>Главный список</a>";
echo "<table>";
$olg_name = '';
while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
    if ($old_name != $line['name'].$line['full_name'] ) {
        echo "</table></br><table border='1'><tr>\n";
        echo "<tr><th colspan='5'>".$line['name']."   ".$line['full_name']."</th></tr>";
        foreach ($column as $key=>$one)
            echo "<th>".$key."</th>";
        echo "</tr>";
        $old_name = $line['name'].$line['full_name'];
    }


$sc = "#888";
if ($line["status"]=='A')
    $sc = "MediumSeaGreen";
if ($line["status"]=='X')
    $sc = "Dimgray";
if ($line["status"]=='N')
    $sc = "Tomato";

#----

echo "<tr style = 'background-color:".$sc."'>";
foreach ($column as $one) {

echo "<td>";
        echo $line[$one];
echo "</td>";
}

}

} else
{

$query_main = "select project.name,project.customer,project.date_created,project.created_by,project.status,
count(sample_number) as count_sample, row_number() OVER(order by name) as nn from sample
inner join project on project.name = sample.project
where closed ='F' and project.status not in ('X','P','U','I') and sample.parent_aliquot=0 and sample.status='A'
group by  project.name,project.customer,project.date_created,project.created_by,project.status
having count(sample_number) > 1
order by name
";

echo "<table border='1px'>";
echo "<tr>";
echo "<td><a href='/' class=button-style> Главная </td>";
echo "</tr>";
echo "</table>";

$result_main = pg_query($query_main) or die('Ошибка запроса: ' . pg_last_error());
echo "<h2>Cписок открытых проектов где количество образцов >=2</h2>";


echo "<table border='1' id='protocol_table'>";
foreach ($column_main as $key=>$one)
    echo "<th>".$key."</th>";

while ($line = pg_fetch_array($result_main, null,  PGSQL_ASSOC)) {
$sc = "#888";
if ($line["status"]=='V')
    $sc = "MediumSeaGreen";
if ($line["status"]=='X')
    $sc = "Dimgray";
if ($line["status"]=='N')
    $sc = "Tomato";

#----
echo "<tr style = 'background-color:".$sc."'>";
foreach ($column_main as $one) {

echo "<td>";
    if ($one=='name')
        echo '<a href="group.php?project='.$line[$one].'"  class=button-style>'.$line[$one].'</a>';
    else
        echo $line[$one];
echo "</td>";
}

}



}
