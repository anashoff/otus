<html>
 <meta http-equiv="refresh" content="300">

<?php

// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.50.251 dbname=LIMS_PUSCHINO_DEV user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


function draw_sample($line) {
# рисуем этикетку единичного образца
#картинка | код | показатель
#         | соп | матрица |
if ($line['c_urgency'] == 'STD')
{
    $bg = "#ccc" ; #цвет по умолчанию
    $urg = "";
}
else
{
    $bg = "#Faa";#цвет по умолчанию
    $urg  = " (СРОЧНО)";
}
#echo $line['bo'];
if (strlen($line['bo'])>0) {
$bo='<tr><td colspan="3">'.$line['bo'].'</td></tr>';
} else 
$bo = '';
#echo $bo;

$ret = '<table border="1" bgcolor="'.$bg.'">
<tr>
    <td rowspan="2"><img></img></td>
    <td><b>'.$line['c_protocol_number'].$urg.'</b></td>
    <td>'.$line['text_id'].'</td>
    <td></td>
</tr>
<tr>
    <td colspan="3"colspan="3"><u>'.$line['name'].'</u></td>
</tr>	
<tr>
    <td>'.$line['analysis'].'</td>
    <td colspan="3">'.$line['string_agg'].'</td>
</tr>'.$bo.'</table>';

return $ret;

}







// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select name from lab";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
echo "<table border='1px'>\n";
echo "\t<tr>\n";
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {

#    foreach ($line as $col_value) {
        echo "\t\t<td><a href='?lab=$line[0]'>$line[0]</a></td>\n";
#    }
}
echo "<td><a href='?lab=СХРМИ&room=ХР-134'>ХР-134</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-218'>ХР-218</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-219'>ХР-219</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-220'>ХР-220</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-221'>ХР-221</td>";
    echo "\t</tr>\n";

echo "</table>\n";

// Очистка результата
pg_free_result($result);




$getlab = $_REQUEST['lab'];
$getroom = $_REQUEST['room'];

#echo $lab;
preg_match ("/[a-zA-Zа-яА-Я]+/msiu",$getlab,$matches);
#print_r ($matches);
$lab = $matches[0];

preg_match ("/[a-zA-Zа-яА-Я-0-9]+/msiu",$getroom,$matches);
#print_r ($matches);
$room = $matches[0];

if (strlen($room)>0) 
$qroom = " and sample.aliquot_group like '".$room."%' ";
else
$qroom="";

#exit(0);

if (strlen($lab)>0) {
#1
echo "<table border='1px'>\n";
echo "<tr><td  style='vertical-align:top'>\n";


##############################
#2
#####################################
echo "<table style='border-spacing: 5px '>\n";
echo "<tr><th colspan='4'>В процессе регистрации</th></tr>\n\n";

#echo "<tr><td>";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab'";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 


$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis),
    c_proj_approval.urgency as c_urgency
    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
    inner join c_proj_approval on c_proj_approval.project = project.name 

    where sample.status='U' 
    and test.lab='$lab' and test.analysis not like '%\_%'
    and project.customer <> 'TEST_EXAMPLE' ".$qroom."
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,c_proj_approval.urgency order by sample.text_id " ;
#    order by test.analysis,test.reported_name ";



    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
$total=0;
#echo "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    echo "\t<tr><td>\n";
    $total = $total + 1;
    echo draw_sample($line);

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
    echo "\t</td></tr>\n";
}
echo "<tr><td colspan='4'>Всего не получено $total</td></tr>";

echo "</table>\n";


echo "\n</td>";

###################### 

echo "<td  style='vertical-align:top'>";
echo "<table style='border-spacing: 5px '>";
echo "<tr><th colspan='4'>Забрать в ГПП!!!</th></tr>";
echo "<tr><td>";


#select storage_movement.*,project.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name,sample.*
#    from test
#    left outer join sample on test.sample_number=sample.sample_number
#    left outer join c_product on sample.c_product=c_product.id
#    left outer join project on sample.project = project.name
#    left outer join storage_movement on storage_movement.object_id = sample.sample_number
#	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
#    where test.status='I' and (sample.status='I' or sample.status='P')
#    and test.lab='СХРМИ' and test.analysis  not like '%\_%'
#    and project.customer <> 'TEST_EXAMPLE' 
#    order by test.analysis,test.reported_name








#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name";
#$query = "select storage_movement.current_location,sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 

$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis), c_proj_approval.urgency as c_urgency
    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
    inner join c_proj_approval on c_proj_approval.project = project.name 

    where test.status='I' and (sample.status='I' or sample.status='P') and storage_movement.current_location = 175
    and test.lab='$lab' and test.analysis not like '%\_%'  
    and project.customer <> 'TEST_EXAMPLE' ".$qroom."
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,c_proj_approval.urgency order by sample.text_id " ;
#    order by test.analysis,test.reported_name ";

#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name";

    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
$total=0;
#echo "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    echo "\t<tr><td>\n";
    $total = $total + 1;
    echo draw_sample($line);

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
    echo "\t</td></tr>\n";
}
echo "<tr><td colspan='4'>Всего не получено $total</td></tr>";
echo "</table>\n";

echo "</td>";




###########################


#echo "<td>";
#\necho "<table>";

echo "<td style='vertical-align:top'>";
echo "<table style='border-spacing: 5px 'style='border-spacing: 5px '>\n";
echo "<tr><th colspan='4'>В работе</th></tr>\n";

#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='P' and test.status='P' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 
#    from test 
#    left outer join sample on test.sample_number=sample.sample_number 
#    left outer join c_product on sample.c_product=c_product.id 
#    left outer join project on sample.project = project.name
#
#    where sample.status='P' and test.status='P' 
#    and test.lab='$lab' and test.analysis not like '%\_%'  
#    and project.customer <> 'TEST_EXAMPLE'
#
#    order by test.analysis,test.reported_name ";


#$query = "select storage_location.description as stor,sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name --
#string_agg(batch_objects.batch ,'<br>' order by test.analysis) as bo
$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis),
(select string_agg(batch,'<br>') from batch_objects where batch_objects.sample_number = sample.sample_number) as bo, c_proj_approval.urgency as c_urgency

    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
    left outer join storage_location on storage_location.location_number=storage_movement.current_location
    inner join c_proj_approval on c_proj_approval.project = project.name 


    where ((test.status='I' and (sample.status='I' or sample.status='P')  and  storage_movement.current_location <> 175) or (sample.status='P' and test.status='P' ))
    and test.lab='$lab' and test.analysis not like '%\_%'  
    and project.customer <> 'TEST_EXAMPLE'  ".$qroom." 
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,sample.sample_number, c_proj_approval.urgency order by sample.text_id";
#    order by test.analysis,test.reported_name ";
#    left outer join batch_objects on batch_objects.sample_number = sample.sample_number




    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
$total=0;
#\necho "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    echo "\t<tr><td>\n";
    $total = $total + 1;
    echo draw_sample($line);
#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
    echo "\t</td></tr>\n";
}
echo "<tr><td colspan='4'>Всего  в работе $total</td></tr>";

echo "</table>\n";



// Очистка результата
pg_free_result($result);
}


// Закрытие соединения
pg_close($dbconn);
?>
</html>