<html>
<body>

<style>
.error {color:red;}
.re {text-decoration: line-through;}
.nre {text-decoration: none;}

</style>

<?php
$start = microtime(true);
$ip = array(
"192.168.50.102", #developer
"192.168.50.28", #k1
"192.168.50.29", #k2
"192.168.50.30", #k3
"192.168.50.22", #NE
"192.168.50.82", #valentina wifi
"192.168.50.83", #valentina lan
"192.168.50.121", #feilx lan
"192.168.50.41", #note32 wifi

);

if (!in_array($_SERVER['REMOTE_ADDR'], $ip)) {
echo "FILL for ".$_SERVER['REMOTE_ADDR'];
exit(0);
}
#if ($_SERVER['REMOTE_ADDR']=="192.168.50.101") {
#
#
#echo "fgis";
#exit(0);
#}




// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.50.251 dbname=LIMS_PUSCHINO_DEV user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


function query_plus($query,$show=false) {
    //$query = "select name,value from list_entry where list = 'C_MILLING_TYPE' and name !='NONE_MILLING' order by name ";
    if ($query) {
        if ($show) echo "<p>".$query."</p>";
        $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
        return pg_fetch_all($result);
    } else
        return false;
}


function get_by_okpd($okpd) {
#получаем номер (текст) объекта по окад
$ret = query_plus("select name::varchar(45) from c_product where okpd = '$okpd' ");
return $ret[0]['name'];
//print_r($ret);
//echo count($ret);

}





 if  ( $_SERVER['REQUEST_METHOD'] == "POST"){
//        print_r($_POST);
#        echo $_SERVER['REMOTE_ADDR'];
    $ins=array();
    $ins['id']='';
#    if ($_POST['location']) 
        $ins['location'] =    "'".pg_escape_string ($_POST['location'])."'";
#    else $ins['location'] = '';

    if ($_POST['num']) {
        $ins['num'] = (int)$_POST['num'];
    } else $ins['num']= 20;
#    if ($ins['num'] >20) $ins['num']= 20;
    $badcounter=0;
    $goodcounter=0;
    if ($_POST['verbose']=="on") $verbose=true; else $verbose=false;
        
}
?>
<form method="post" id="mainForm">
<table border="1">

<tr>
<td>Подразделение</td>
<td>
<select class="required" name="location" id="location">
    <option></option>
    <option value="СХРМИ">СХРМИ</option>
    <option value="СФХМИ">СФХМИ</option>
    <option value="ГРМИ">ГРМИ</option>
    <option value="ГМГМИ">ГМГМИ</option>
    <option value="ГИФФ">ГИФА</option>
    <option value="СОМИ">СОМИ</option>
    <option value="СЕРОЛОГИЯ">СЕРОЛОГИЯ</option>
    <option value="СМБМИ">СМБМИ</option>
 </select>
</td>
</tr>

<tr>
<td>Количество методик для сверки</td>
<td><input  type="text" name="num" id="num" size="45" value="20"/></td>
</tr>
<tr>
<td>Подробный отчет</td>
<td><input  type="checkbox" name="verbose" id="verbose" size="45"/></td>
</tr>


<tr><td><input type="submit" name="submit" value="Прочитать"/></td><td></td></tr>

</table>

</form>

<?php 
#print_r($ins);
#1 получаем методки подразделения
if (($_SERVER['REQUEST_METHOD'] == "POST") and ($ins['location']!="''")) {
# шаг 1 - получаем все методики подразделения
$step1 = query_plus("
select c_metodics.code,indicator,object_group,metod,location,c_product_group.c_product,c_product_group.internal_doc,c_metodics.internal_doc 
from c_metodics,c_product_group
where c_metodics.active='T' and c_product_group.id=c_metodics.object_group and location = ".$ins['location']);

$step1 = query_plus("select distinct(code) from  c_metodics
where location = ".$ins['location']);



} else  {
    echo "нобходимо указать подразделение";
    exit(0);
}
echo "<p><b>Шаг 1. Проверяется ".count($step1)." методик подразделения ".$ins['location']."</b></p>";

foreach ($step1 as $one) {
# Шаг 2 - для каждой методики получаем все коды ОКПД
$step1_1 = query_plus("
select c_metodics.code,c_metodics.version,indicator,object_group,metod,location,c_product_group.c_product,c_product_group.internal_doc,c_metodics.internal_doc 
from c_metodics,c_product_group
where c_product_group.id=c_metodics.object_group and c_metodics.code = '".$one['code']."' order by c_metodics.version desc limit 1 ");
#print_r($step1_); 


if ($step1_1[0]['c_product']) {
    $step2=query_plus("select okpd,name from c_product where id in (".$step1_1[0]['c_product']." ) order by length(okpd)" ) ;
    echo "<p>Шаг 2. Проверяется ".count($step2)." объектов для методики ".$step1_1[0]['internal_doc']." (".$one['code'].")</p>";
#    print_r($step2);exit(0); 
    }
else
    echo "<p class='error'>Шаг 2. Критическая ошибка, не указаны объекты исследования для методики ".$one['code']."</p>";



foreach($step2 as $two) {
$milling_type = "";

# print_r($step1_1);
  $step2_1=query_plus("select parents('".$two['okpd']."') as okpd" );
#  print_r($two);print_r($step2_1);exit(0);
  foreach($step2_1 as $parent) {
$step3=query_plus("select c_product.name,c_product.consistency,c_milling.* from c_milling,c_product
where c_milling.id >0 and 
(c_milling.location = '".$step1_1[0]['location']."') and 
(c_milling.indicator = '".$step1_1[0]['indicator']."' or c_milling.indicator is null) and 
(c_milling.object = '".$parent['okpd']."' or c_milling.object is null) 
and (c_product.okpd = '".$parent['okpd']."') and
( (c_milling.consistency is null) or c_product.consistency=c_milling.consistency) 
order by c_milling.indicator,c_milling.metod,length(c_milling.object) desc",false);



  if (is_array($step3)) {
#    echo "m=".$milling_type;    print_r($step3);#exit(0);

    if (($milling_type != "") and ($milling_type!=$step3[0]['milling_type'])) {
        echo "<p class='error'>Предупреждение, разный размол:  ".$milling_type." для ".$two['name']." (".$two['okpd'].") != ".$step3[0]['milling_type']." для ". get_by_okpd($parent['okpd'])." (". $parent['okpd'].") ".$step1_1[0]['indicator']."</p>";
    
	}
    elseif ($milling_type == "")
        {  
        if ($verbose)
            echo "<p>Размол ".$step3[0]['milling_type']."  для ".$two['name']."(ОКПД ". $two['okpd'].") ".$step1_1[0]['indicator']."</p>";
        else
            echo ".";
        $milling_type=$step3[0]['milling_type'];
        }
  }
# foreach step2_1
  }
if ($milling_type=="")
     {
    $badcounter = $badcounter + 1;
    echo "<p class='error'>Предупреждение №".$badcounter.", не определен размол  для ".$two['name']." (ОКПД  ".$two['okpd'].")  ".$step1_1[0]['indicator']."</p>";

    if ($badcounter >= $ins['num'])
        break(2);
    } else
    $goodcounter = $goodcounter + 1;
}
#exit(0);



}

$finish = microtime(true);

$delta = $finish - $start;
echo "<p><b>ИТОГО для ".$ins['location']."</b><p>";
echo "<p><b>Определён размол: ".$goodcounter."</b><p>";
echo "<p><b>Не определён размол: ".$badcounter."</b><p>";
echo "<p>Время выполнения: ".$delta . " сек.</p>";

?>
</body>
</html>