<html>
 <meta http-equiv="refresh" content="300">

<?php

// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.50.251 dbname=LIMS_PUSCHINO_DEV user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");

function draw_digit($digit) {
# рисуем число
if ($digit > 0) 
    return "<b>".$digit."</b>";
else
    return " ";

}

function status($status) {
# рисуем число
if ($status == 'A') 
    return "<b>Авторизовано</b>";
elseif ($status == 'C') 
    return "<b>Ждёт авторизации</b>";
elseif ($status == 'P') 
    return "<b>В работе</b>";
elseif ($status == 'I') 
    return "<b>Не начат</b>";

else
    return $status;

}


function draw_sample($line,$col) {
# рисуем этикетку единичного образца
#картинка | код | показатель
#         | соп | матрица |

# для первого столбца проверяем нет ли витаминов

#$vit = 0;
#if ($col <= 2) {
#$queryfreeze = "select count(test_number)
#from test
#inner join sample on test.sample_number=sample.sample_number
#where
#test.analysis in ('СОП.М.ХР.011.1','СОП.М.ХР.013.1','СОП.М.ХР.018.1','СОП.М.ХР.020.1','СОП.М.ХР.021.1', --витамин а
#'СОП.М.ХР.011.2','СОП.М.ХР.013.1','СОП.М.ХР.018.1','СОП.М.ХР.020.2','СОП.М.ХР.021.1','СОП.М.ХР.040.1','СОП.М.ХР.063.1' --витамин e
#) and
#sample.c_protocol_number = '".$line['c_protocol_number']."'";
#print($queryfreeze);
#print($line['c_protocol_number']);
#$resultfreeze = pg_query($queryfreeze) or die('Ошибка запроса: ' . pg_last_error());
#print_r(pg_fetch_array($resultfreeze, null,  PGSQL_NUM ));
#$vit = pg_fetch_array($resultfreeze, null,  PGSQL_NUM )[0];

#} else
#$vit = 0;

$date_diff_work = $line['date_diff_work'];

#print($vit);
if ($line['project_urgency'] == 'STD')
{
    if ($date_diff_work>=9) {
        $bg = "#F50" ; #цвет шапки
        $bg2 = "#F50"; #цвет тела
    } elseif ($date_diff_work == 8){
        $bg = "#FAA" ; #цвет шапки
        $bg2 = "#FAA";
    } elseif ($date_diff_work == 7){
        $bg = "#FFA" ; #цвет шапки
        $bg2 = "#FFA";
    } elseif ($date_diff_work == 6){
        $bg = "#5F0" ; #цвет шапки
        $bg2 = "#5F0" ;
    }
    $urg = "";
}
else
{
    if ($date_diff_work>=3) {
        $bg = "#F50" ; #цвет шапки
        $bg2 = "#F50"; #цвет тела
    } else {
        $bg = "#FFA" ; #цвет шапки
        $bg2 = "#FFA" ;
    }
    
    $urg  = " (СРОЧНО)";
}
#echo $line['bo'];
if (isset($line['bo']))
if (strlen($line['bo'])>0) {
$bo='<tr><td colspan="3">'.$line['bo'].'</td></tr>';
} else 
$bo = '';
 else 
$bo = '';
#echo $bo;

$ret = '<table border="1" bgcolor="'.$bg.'">
<tr bgcolor="'.$bg.'">
    <td rowspan="2"><big><b>'.$date_diff_work.' дн.</b></big></td>
    <td><b>'.$line['c_protocol_number'].$urg.'</b></td>
    <td>'.$line['login_date'].'</td>
</tr>
<tr bgcolor="'.$bg2.'">
    <td colspan="3" colspan="3">'.$line['reported_name'].' ['.status($line['test_status']).']</td>
</tr>	
<tr bgcolor="'.$bg2.'">
    <td></td>

    <td colspan="3">'.$line['string_agg'].'</td>
</tr>'.$bo.'</table>';


#    <td>'.$line['analysis'].'</td>

return $ret;

}

// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select name from lab";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
// Вывод результатов в HTML
echo "<table border='1px'>\n";
echo "\t<tr>\n";
echo "<td><a href='".$_SERVER['PHP_SELF']."'>Главная</td>";
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {

#    foreach ($line as $col_value) {
        echo "\t\t<td><a href='?lab=$line[0]'>$line[0]</a></td>\n";
#    }
}
echo "<td><a href='?lab=СХРМИ&room=ХР-134'>ХР-134</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-216'>ХР-216</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-218'>ХР-218</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-219'>ХР-219</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-220'>ХР-220</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-221'>ХР-221</td>";
    echo "\t</tr>\n";

echo "</table>\n";

?>


<H3>Countdown v.1.2 от 19.08.2022</H3>


<!--b>Условные обозначения</b>
<table border="1px">
<tr>
<td bgcolor="#ccc" >Обычные образцы</td>
<td bgcolor="#f33">Срочные образцы</td>
<td bgcolor="#99f">Возможна задержка получения из-за <br>особенностей сопутствующих анализов (витамины)</td>
</tr>
</table--!>
<!--b>очередь образцов</b--!>


<?php


// Очистка результата
pg_free_result($result);


$getlab = $_REQUEST['lab'];
if (isset( $_REQUEST['room']))
    $getroom = $_REQUEST['room'];
else
    $getroom = "";
#echo $lab;
preg_match ("/[a-zA-Zа-яА-Я]+/msiu",$getlab,$matches);
#print_r ($matches);
$lab = $matches[0];


preg_match ("/[a-zA-Zа-яА-Я-0-9]+/msiu",$getroom,$matches);
#print_r ($matches);
if (count($matches)>0)
    $room = $matches[0];
else
    $room = "";

if (strlen($room)>0) 
$qroom = " and sample.aliquot_group like '".$room."%' ";
else
$qroom="";

#exit(0);
# главный запрос, который потом дописывается под конкретную выборку

$main_query = "
select sample.c_protocol_number, date_diff_work(login_date::date , now()::date ) as date_diff_work, login_date::date,sample.aliquot_group, 
sample.status as sample_status, test.analysis,test.status as test_status,test.reported_name,c_proj_approval.urgency as project_urgency
from test
inner join sample on sample.sample_number = test.sample_number 
inner join project on sample.project = project.name
inner join c_proj_approval on c_proj_approval.project = project.name
where 
    login_date >= now() - interval '3 month' 
    and parent_aliquot != 0 
    and sample.status not in ('A', 'X') 
    and test.status != 'X' ";

#and date_diff_work(login_date::date , now()::date ) >= 7 and
#and sample.c_urgency != 'STD'


if (strlen($lab)>0) {
    $main_query = $main_query."    and test.lab='".$lab."' and test.analysis not like '%\_%'  ".$qroom." ";
}

if (strlen($lab)>0 and $lab !='ОБЩ') {
#1
echo "<table border='1px'>\n";
echo "<tr><td  style='vertical-align:top'>\n";


##############################
#2
#####################################

#echo "<tr><td>";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab'";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 


$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis),
    c_proj_approval.urgency as c_urgency,sample.t_sample_comment
    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
    inner join c_proj_approval on c_proj_approval.project = project.name 

    where sample.status='U' 
    and test.lab='$lab' and test.analysis not like '%\_%'
    and project.customer <> 'TEST_EXAMPLE' ".$qroom."
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,c_proj_approval.urgency,sample.t_sample_comment order by sample.text_id " ;
#    order by test.analysis,test.reported_name ";


    $query = $main_query."  and c_proj_approval.urgency  != 'STD' order by date_diff_work desc,sample.c_protocol_number desc";

    

    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
    $r_rows = pg_num_rows($result);

// Вывод результатов в HTML
echo "<table style='border-spacing: 5px '>\n";
echo "<tr><th colspan='4'>Срочные образцы ($r_rows)</th></tr>\n\n";
#echo "<tr><td colspan='4'>{$main_query}</td></tr>\n\n";


$total=0;
#echo "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    echo "\t<tr><td>\n";
    $total = $total + 1;
    echo draw_sample($line,1);

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
    echo "\t</td></tr>\n";
}
# echo "<tr><td colspan='4'>Больше 10 дней $total</td></tr>";

echo "</table>\n";


echo "\n</td>";

###################### 

echo "<td  style='vertical-align:top'>";


#select storage_movement.*,project.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name,sample.*
#    from test
#    left outer join sample on test.sample_number=sample.sample_number
#    left outer join c_product on sample.c_product=c_product.id
#    left outer join project on sample.project = project.name
#    left outer join storage_movement on storage_movement.object_id = sample.sample_number
#	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
#    where test.status='I' and (sample.status='I' or sample.status='P')
#    and test.lab='СХРМИ' and test.analysis  not like '%\_%'
#    and project.customer <> 'TEST_EXAMPLE' 
#    order by test.analysis,test.reported_name

#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name";
#$query = "select storage_movement.current_location,sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 

$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis), c_proj_approval.urgency as c_urgency,t_sample_comment
    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
    inner join c_proj_approval on c_proj_approval.project = project.name 

    where test.status='I' and (sample.status='I' or sample.status='P') and storage_movement.current_location = 175
    and test.lab='$lab' and test.analysis not like '%\_%'  
    and project.customer <> 'TEST_EXAMPLE' ".$qroom."
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,c_proj_approval.urgency,t_sample_comment order by sample.text_id " ;
#    order by test.analysis,test.reported_name ";

#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name";


    $query = $main_query."  and c_proj_approval.urgency  = 'STD' and date_diff_work(login_date::date , now()::date )>= 10  order by date_diff_work desc,sample.c_protocol_number desc";

    

    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
    $r_rows = pg_num_rows($result);

// Вывод результатов в HTML
echo "<table style='border-spacing: 5px '>";
echo "<tr><th colspan='4'>Больше 9 дней!!! ($r_rows)</th></tr>";
#echo "<tr><td colspan='4'>{$query}</td></tr>\n\n";
echo "<tr><td>";



$total=0;
#echo "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    echo "\t<tr><td>\n";
    $total = $total + 1;
    echo draw_sample($line,2);

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
    echo "\t</td></tr>\n";
}
#echo "<tr><td colspan='4'>от 7 до 10 дней $total</td></tr>";
echo "</table>\n";

echo "</td>";




###########################


#echo "<td>";
#\necho "<table>";

echo "<td style='vertical-align:top'>";

#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='P' and test.status='P' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 
#    from test 
#    left outer join sample on test.sample_number=sample.sample_number 
#    left outer join c_product on sample.c_product=c_product.id 
#    left outer join project on sample.project = project.name
#
#    where sample.status='P' and test.status='P' 
#    and test.lab='$lab' and test.analysis not like '%\_%'  
#    and project.customer <> 'TEST_EXAMPLE'
#
#    order by test.analysis,test.reported_name ";


#$query = "select storage_location.description as stor,sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name --
#string_agg(batch_objects.batch ,'<br>' order by test.analysis) as bo
$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis),
(select string_agg(batch,'<br>') from batch_objects where batch_objects.sample_number = sample.sample_number) as bo, c_proj_approval.urgency as c_urgency,t_sample_comment

    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
    left outer join storage_location on storage_location.location_number=storage_movement.current_location
    inner join c_proj_approval on c_proj_approval.project = project.name 


    where ((test.status='I' and (sample.status='I' or sample.status='P')  and  storage_movement.current_location <> 175) or (sample.status='P' and test.status='P' ))
    and test.lab='$lab' and test.analysis not like '%\_%'  
    and project.customer <> 'TEST_EXAMPLE'  ".$qroom." 
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,sample.sample_number, c_proj_approval.urgency,t_sample_comment order by sample.text_id";
#    order by test.analysis,test.reported_name ";
#    left outer join batch_objects on batch_objects.sample_number = sample.sample_number


    $query = $main_query."  and c_proj_approval.urgency  = 'STD' and date_diff_work(login_date::date , now()::date )>6 and date_diff_work(login_date::date , now()::date ) < 10  order by date_diff_work desc,sample.c_protocol_number desc";


    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
    $r_rows = pg_num_rows($result);

// Вывод результатов в HTML
echo "<table style='border-spacing: 5px 'style='border-spacing: 5px '>\n";
echo "<tr><th colspan='4'>6-9 дней ($r_rows)</th></tr>\n";
#echo "<tr><td colspan='4'>{$query}</td></tr>\n\n";



$total=0;
#\necho "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    echo "\t<tr><td>\n";
    $total = $total + 1;
    echo draw_sample($line,3);
#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
    echo "\t</td></tr>\n";
}
# echo "<tr><td colspan='4'>Всего  в работе $total</td></tr>";

echo "</table>\n";



// Очистка результата
pg_free_result($result);
} else 
{
$total_query = "   select sample.aliquot_group,
   sum(case when c_proj_approval.urgency = 'HIGH' then 1 else 0 end) as срочное,
   sum(case when date_diff_work(login_date::date , now()::date )>9 then 1 else 0 end) as больше_9,
   sum(case when date_diff_work(login_date::date , now()::date )>6 and date_diff_work(login_date::date , now()::date )<=9 then 1 else 0 end) as от_7_до_9
  from test inner join sample on sample.sample_number = test.sample_number 
 inner join project on sample.project = project.name 
 inner join c_proj_approval on c_proj_approval.project = project.name 
 where login_date >= now() - interval '3 month' and parent_aliquot != 0 and sample.status not in ('A', 'X') 
 and test.status != 'X'  and test.analysis not like '%\_%' 
-- and c_proj_approval.urgency = 'STD'
 --and date_diff_work(login_date::date , now()::date )>7
  --order by date_diff_work desc,sample.c_protocol_number desc
  group by sample.aliquot_group order by sample.aliquot_group 
";
    $result = pg_query($total_query) or die('Ошибка запроса: ' . pg_last_error());
echo "<h3>сводка</h3>";
echo "<table border='1px'>
<tr><th>Подразделение</th><th>Срочные образцы</th><th>Больше 9 дней!!!</th><th>7-9 дней</th></tr>";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {

echo "<tr><td>".$line['aliquot_group']."</td><td>".draw_digit($line['срочное'])."</td><td>".draw_digit($line['больше_9'])."</td><td>".draw_digit($line['от_7_до_9'])."</td></tr>";

#    echo "\t==".$line['aliquot_group']."\n";
}
echo "</table>";

}



// Закрытие соединения
pg_close($dbconn);
?>
</html>