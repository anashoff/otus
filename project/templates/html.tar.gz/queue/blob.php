<?php
include "auth.php";
if (isset($_REQUEST['read'])) {
#    preg_match ("/[0-9-]+/msiu",$_REQUEST['read'],$matches);
#$org = $matches[0];
$read = pg_escape_string ( $_REQUEST['read'] );



$dbconn = pg_connect("host=192.168.50.202 dbname=LIMS_PUSCHINO_DEV user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());
pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");

header('Content-type: application/pdf');
#header('Accept-Ranges: bytes');
#header('Content-Length: 1006540'); //this is the size of the zipped file
#header('Keep-Alive: timeout=15, max=100');
#header('Content-Disposition: attachment; filename="test.pdf"');

$q_oid = "select db_files.file_contents from T_PROJI_ATTACH -- limit 11
inner join db_files on T_PROJI_ATTACH.attach_db_file = db_files.file_name
where project='".$read."'";
$result = pg_query($q_oid) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($result, null,  PGSQL_ASSOC);
$image_oid = $line['file_contents'];
#exit(0);

#   $image_oid = 1624932;
#   $database = pg_connect("dbname=jacarta");
    pg_query($dbconn, "begin");
    $handle = pg_lo_open($dbconn, $image_oid , "r");
    pg_lo_read_all($handle);
    pg_query($dbconn, "commit");
}

?>