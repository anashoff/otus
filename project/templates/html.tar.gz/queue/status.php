<html>
 <meta http-equiv="refresh" content="300">

<?php


// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


function draw_sample($line) {
# рисуем этикетку единичного образца
#картинка | код | показатель
#         | соп | матрица |
$bg="#ccc";#цвет по умолчанию
#echo $line['bo'];
if (strlen($line['bo'])>0) {
$bo='<tr><td colspan="3">'.$line['bo'].'</td></tr>';
} else 
$bo = '';
#echo $bo;

$ret = '<table border="1" bgcolor="'.$bg.'">
<tr>
    <td rowspan="2"><img></img></td>
    <td><b>'.$line['c_protocol_number'].'</b></td>
    <td>'.$line['text_id'].'</td>
    <td></td>
</tr>
<tr>
    <td colspan="3"colspan="3"><u>'.$line['name'].'</u></td>
</tr>	
<tr>
    <td>'.$line['analysis'].'</td>
    <td colspan="3">'.$line['string_agg'].'</td>
</tr>'.$bo.'</table>';

return $ret;

}

function sc($status) {
if ($status=="A")
    return "green";
if ($status=="C")
    return "cyan";
if ($status=="P")
    return "DodgerBlue";
if ($status=="R")
    return "Orange";
if ($status=="X")
    return "DarkSlateGrey";


}

function ss($text,$status){
if ($status=="X")
    return "<s>".$text."</s>";
else
    return $text;
}

$getlab = $_REQUEST['lab'];
$getroom = $_REQUEST['room'];

preg_match ("/[a-zA-Zа-яА-Я]+/msiu",$getlab,$matches);
$lab = $matches[0];

preg_match ("/[a-zA-Zа-яА-Я-0-9]+/msiu",$getroom,$matches);
$room = $matches[0];

if (strlen($room)>0) 
$qroom = " and sample.aliquot_group like '".$room."%' ";
else
$qroom="";

#exit(0);

#2
echo "<table border='1px' style='border-spacing: 1px '>\n";
echo "<tr><th colspan='9'>Очередь образцов за ".$days." д.</th></tr>\n\n";
echo"<tr><th>№протокола</th><th>СОП</th><th>показатель</th><th>ЕИ</th><th>клиент</th><th>статус образца</th><th>теста</th><th>результата</ht><th>код методики</th></tr>";

$query="select substring(s.c_protocol_number from '^\d+')::int as p_num,r.analysis,r.reported_name,r.c_metodic_code,r.units,r.c_units,p.customer,s.status as sstatus,r.status as rstatus,t.status as tstatus from result r 
inner join test t on t.test_number=r.test_number
inner join sample s on s.sample_number=t.sample_number
inner join project p on p.name=s.project
where r.reported_result='T' and r.displayed='T' and s.c_protocol_number is not null and substring(s.c_protocol_number from '^\d+')::int is not null
and p.date_received >now()-  interval '".$days." day'
and p.customer <> 'TEST_EXAMPLE'
order by p_num desc,s.sample_number,r.analysis,r.result_number";

#and  r.reportable='T'

    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
$total=0;
$bg="#fff";
$old_p_num = 0;
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    if ($old_p_num!=$line['p_num']) {
        $old_p_num=$line['p_num'];
        if ($bg=="#fff")
          $bg="#999";
        else
          $bg="#fff";
        }

    echo "\t<tr bgcolor='".$bg."'><td>\n";
    $total = $total + 1;
    echo $line['p_num'];
    echo "</td><td>";
    echo ss($line['analysis'],$line['tstatus']);
        echo "</td><td bgcolor='".sc($line['tstatus'])."'>";
    echo ss($line['reported_name'],$line['tstatus']);
        echo "</td><td>";

    if (($line['units']!=$line['c_units']) and ($line['c_units']!="")) #(!is_null($line['c_units'])) and
        echo ss("<b>ЕИ клиента! -> ".$line['c_units']."</b>",$line['tstatus']);
    else
        echo ss($line['units'],$line['tstatus']);
        echo "</td><td>";
#    echo $line['c_units'];
#        echo "</td><td>";
    echo $line['customer'];
        echo "</td><td>";
    echo $line['sstatus'];
        echo "</td><td>";
    echo $line['tstatus'];
        echo "</td><td>";
    echo $line['rstatus'];
        echo "</td><td>";
    echo $line['c_metodic_code'];

#    foreach ($line as $one)
#        {
#        echo $one;
#        echo "</td><td>";
#        }

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
    echo "\t</td></tr>\n";
}
echo "<tr><td colspan='4'>Всего $total</td></tr>";

echo "</table>\n";


echo "\n</td>";

###################### 

echo "</table>\n";



// Очистка результата
pg_free_result($result);



// Закрытие соединения
pg_close($dbconn);
?>
</html>
