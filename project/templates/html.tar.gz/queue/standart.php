

<html>
  <head>
      <link rel="stylesheet" href="../css/table.css"> <!-- Путь к CSS файлу -->
  </head>


 <meta http-equiv="refresh" content="300">

<?php

// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");








// Выполнение SQL-запроса
#$query = 'SELECT name, status FROM project';
$query = "select name from lab";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
echo "<table border='1px'>\n";
echo "\t<tr>\n";
while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {

#    foreach ($line as $col_value) {
        echo "\t\t<td><a href='?lab=$line[0]' class=button-style >$line[0]</a></td>\n";
#    }
}
#echo "<td><a href='?lab=СХРМИ&room=ХР-134' class=button-style>ХР-134</td>";
#echo "<td><a href='?lab=СХРМИ&room=ХР-218' class=button-style>ХР-218</td>";
#echo "<td><a href='?lab=СХРМИ&room=ХР-219' class=button-style>ХР-219</td>";
#echo "<td><a href='?lab=СХРМИ&room=ХР-220' class=button-style>ХР-220</td>";
#echo "<td><a href='?lab=СХРМИ&room=ХР-221' class=button-style>ХР-221</td>";
echo "<td><a href='?lab=DEFAULT' class=button-style>Общие</td>";
echo "<td><a href='/' class=button-style>Главная</td>";
    echo "\t</tr>\n";

echo "</table>\n";

// Очистка результата
pg_free_result($result);




$getlab = $_REQUEST['lab'];
$getroom = $_REQUEST['room'];

#echo $lab;
preg_match ("/[a-zA-Zа-яА-Я]+/msiu",$getlab,$matches);
#print_r ($matches);
$lab = $matches[0];

preg_match ("/[a-zA-Zа-яА-Я-0-9]+/msiu",$getroom,$matches);
#print_r ($matches);
$room = $matches[0];

if (strlen($room)>0) 
$qroom = " and sample.aliquot_group like '".$room."%' ";
else
$qroom="";

#exit(0);

if (strlen($lab)>0) {
#1
echo "<table border='1px'>\n";
#echo "<tr><td  style='vertical-align:top'>\n";


##############################
#2
#####################################
#echo "<table style='border-spacing: 5px '>\n";
echo "<tr><th colspan='7'>Показатели в работе</th></tr>\n\n";
echo "<tr><th>№</th>
<th>Стандарт</th>
<th>Срок годности</th>
<th>Показатель</th>
<th>Значение</th>
<th>ЕИ значения</th>
<th>Неопределенность</th>
<th>ЕИ неопределенности</th>
<tr>
";
#echo "<tr><td>";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab'";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 



$query="select stock,
case when inventory_item.t_expiration_date < (now() + interval '2 month') then 
    ('<span style=\"background-color:#ff7700\">' || (to_char(inventory_item.t_expiration_date,'DD.MM.YYYY'))::text || '</span>')
else
    to_char(inventory_item.t_expiration_date,'DD.MM.YYYY')
end as t_expiration_date,
c_inv_metrlg_char.certified_feature,c_inv_metrlg_char.certified_value,c_inv_metrlg_char.certified_units,
c_inv_metrlg_char.accuracy_value,c_inv_metrlg_char.accuracy_units 
from inventory_entry 
inner join inventory_item on inventory_item.item_number = inventory_entry.item_number
inner join stock on stock.name = inventory_item.stock
left join c_inv_metrlg_char on c_inv_metrlg_char.inventory_item = inventory_entry.item_number
where inventory_entry.inventory_type='СТАНДАРТ' and stock.c_accreditation ='T' and inventory_item.t_expiration_date>now()
and stock.group_name='$lab'
order by stock.group_name,inventory_item.stock";



    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
// Вывод результатов в HTML
$total=0;
#echo "<table>\n";
while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
    $total = $total + 1;
    echo "<tr><td>".$total."</td>
<td>".$line['stock']."</td>
<td>".$line['t_expiration_date']."</td>
<td>".$line['certified_feature']."</td>
<td>".$line['certified_value']."</td>
<td>".$line['certified_units']."</td>

<td>".$line['accuracy_value']."</td>
<td>".$line['accuracy_units']."</td>
</tr>";
#print_r($line);

}
#	echo "<tr><td colspan='2'><b>Всего  $total</b></td></tr>";

echo "</table>\n";


#echo "\n</td>";


#echo "</table>\n";



// Очистка результата
pg_free_result($result);
}


// Закрытие соединения
pg_close($dbconn);
?>
</html>
