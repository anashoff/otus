


select to_char(date_reviewed,'YYYY-MM'),
sum(case when entry < 0.3 then 1 else 0 end) as less03,
sum(case when entry >= 0.3 and entry < 10 then 1 else 0 end) as in03_10 ,
sum(case when entry >=10 and entry < 50 then 1 else 0 end) as in10_50 ,
sum(case when entry >= 50  then 1 else 0 end) as more50,
count(entry),
percentile_cont(0.5) WITHIN GROUP (ORDER BY entry),
max(entry)
from  (
    select replace(entry,',','.')::float as entry, sample.date_reviewed from result
    inner join sample on sample.sample_number = result.sample_number
    inner join c_product on c_product.id = sample.c_product
    where c_metodic_code like '%.245')
    and sample.date_reviewed >='2021-11-01' and sample.date_reviewed <'2022-05-01'
    and sample.status = 'A' and result.status = 'A'
    and c_product.name ilike '%кукуруз%' ORDER BY entry
) as rr 
group by to_char(date_reviewed,'YYYY-MM') 
order by to_char(date_reviewed,'YYYY-MM')
