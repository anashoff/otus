<?php
#include "auth.php";
// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.50.202 dbname=LIMS_PUSCHINO_DEV user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


function depload($sop,$test_location,$date) {
$query_one = "select count(test_number) from test where analysis like left('".$sop."',12)||'%' and test.t_date_enabled < '".$date."' and test.date_reviewed>'".$date."'";
$query_all = "select count(test_number) from test where analysis like left('".$sop."',9)||'%' and test.test_location='".$test_locatio."'and test.t_date_enabled < '".$date."' and test.date_reviewed>'".$date."'";

$result_one = pg_query($query_one) or die('Ошибка запроса: ' . pg_last_error());
$result_all = pg_query($query_all) or die('Ошибка запроса: ' . pg_last_error());
$line_one = pg_fetch_array($result_one, null,  PGSQL_ASSOC);

return "Загрузка СОП: ".$line_one[0]." | Комната: ".$line_all[0];

}



$column = [
    "№"=>"nn",
    "показатель"=>"name",
    "аликвота в работе, раб дней"=>"aliquot_work",
    "тест в работе, раб дней"=>"test_work",
    "результат в работе, дней"=>"result_work",
    "тест начат через Х дней после получения"=>"test_start_after_login",
    "добвлено через Х дней после получегни"=>"add_later_after_login",
];

$column_main = [
    "№"=>"nn",
    "Проект"=>"name",
    "Количество образцов"=>"count_sample",
    "заказчик"=>"customer",
    "дата регистрации"=>"date_created",
    "ГПП"=>"created_by",
    "Статус"=>"status"

];

echo "<h1>analytic.php</h1>";


$handle = @fopen("2022-m01.txt", "r");
if ($handle) {
    echo "<table border='1' id='protocol_table'>";
    echo "<tr>
<th>№</th>
<th>Имя образца</th>
<th>Протокол</th>
<th>Дата регистрации</th>
<th>Общее время выполнения</th>
<th>Доназначения</th>
<th>Поздний старт</th>
<th>Долго делали</th>
<th>ожидание готовых тестов</th>
</tr>";
    $nn = 0;
    while (($sample_name = fgets($handle, 4096)) !== false) {
        $nn += 1;
        echo "<tr><td>".$nn."</td>";
        echo "<td>".$sample_name."</td>";
        echo "<td>".analise_by_name($sample_name)."</td>";
        echo "</tr>";


########################## конец работы с одним образцом
    } 
    
    if (!feof($handle)) {
        echo "Ошибка: fgets() неожиданно потерпел неудачу\n";
    }
    fclose($handle);
}






exit(0);


function analise_by_name($sample_name) {
$query = "
select result.name,sample.c_protocol_number,original.login_date::date,date_diff_work(original.login_date::date,original.date_reviewed::date) as sample_total,
date_diff_work(sample.login_date::date,sample.date_reviewed::date) as aliquot_work,
date_diff_work(sample.recd_date::date,sample.date_reviewed::date) as department_work,
date_diff_work(test.t_date_enabled::date,test.date_reviewed::date) as test_work,
date_diff_work(test.t_date_enabled::date,result.date_reviewed::date) as result_work,
date_diff_work(sample.login_date::date,test.date_started::date) as test_start_after_login,
date_diff_work(sample.login_date::date,test.t_date_enabled::date) as add_later_after_login,
date_diff_work(sample.date_reviewed::date,r.date_created::date) as protocol_work
from result
inner join test on test.test_number = result.test_number
inner join sample on result.sample_number = sample.sample_number
inner join report_objects ro on ro.object_id = sample.original_sample
inner join reports r on r.report_number = ro.report_number
inner join sample original on original.sample_number = sample.original_sample

where sample.c_protocol_number = '".trim($sample_name)."' and result.c_metodic_code is not null
and result.status ='A' and test.status ='A' and sample.status ='A' and 
((result.protocol_type='Y' and r.c_in_accreditation='T') or (result.protocol_type='N' and r.c_in_accreditation='F'))
order by add_later_after_login,test.analysis,result.order_number";

#where sample.sample_name like '%".trim($sample_name)."%' and result.c_metodic_code is not null

$tmp = "
select result.name,sample.c_protocol_number,sample.login_date::date,date_diff_work(sample.login_date::date,sample.date_reviewed::date) as aliquot_work,
date_diff_work(sample.recd_date::date,sample.date_reviewed::date) as department_work,
date_diff_work(test.t_date_enabled::date,test.date_reviewed::date) as test_work,
date_diff_work(test.t_date_enabled::date,result.date_reviewed::date) as result_work,
date_diff_work(sample.login_date::date,test.date_started::date) as test_start_after_login,
date_diff_work(sample.login_date::date,test.t_date_enabled::date) as add_later_after_login,
test.analysis --,test.test_location
from result 
inner join test on test.test_number = result.test_number
inner join sample on result.sample_number = sample.sample_number
where sample_name like '%".trim($sample_name)."%' and result.c_metodic_code is not null 
and result.status ='A' and test.status ='A' and sample.status ='A' 
order by add_later_after_login,test.analysis,result.order_number";

$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

$sc = '';
#    echo "<table border='1' id='protocol_table'>";
#    foreach ($column as $key=>$one)
#        echo "<th>".$key."</th>";


#"аликвота в работе, раб дней"=>"aliquot_work",
#"тест в работе, раб дней"=>"test_work",
#"результат в работе, дней"=>"result_work",
#"тест начат через Х дней после получения"=>"test_start_after_login",
#"добвлено через Х дней после получегни"=>"add_later_after_login",

$max_add = 0;
$add_later_names = ""; #"Доназначения: ";
$test_start_after = ""; # "Поздний старт: ";
$aliquot_work = "";
$protocol_work = "";
$c_protocol_number= "";
$login_date = [];
$c_protocol_numbe = [];
$load = "";

while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {




    $login_date[]=$line['login_date'];
    $sample_total=$line['sample_total'];
    if ($sample_total < 9) 
        $sample_mark = "green";
    if (($sample_total == 9) or ($sample_total == 10))
        $sample_mark = "yellow";
    if ($sample_total == 11) 
        $sample_mark = "orange";
    if ($sample_total > 11) 
        $sample_mark = "red";

#    if (($line['c_protocol_number'] != $c_protocol_number) and ($line['c_protocol_number']!='') )
    $c_protocol_number[]= $line['c_protocol_number'];

    if ($line["add_later_after_login"] > 2)
        $add_later_names = $add_later_names.$line['name']." (".$line["add_later_after_login"] .") <br>";

    if (($line["test_start_after_login"] > 5) and ($line["add_later_after_login"] <= 2))
        $test_start_after = $test_start_after.$line['name']." (".$line["test_start_after_login"] .")  <br>";

    if (($line["department_work"] > 8) and ($line["add_later_after_login"] <= 2) and ($line["test_start_after_login"] <= 5))
        $aliquot_work = $aliquot_work.$line['name']." (".$line["department_work"] .")  <br>";

    if ( ($line["protocol_work"] > 2) and ($line["department_work"] <= 8) and ($line["add_later_after_login"] <= 2) and ($line["test_start_after_login"] <= 5))
        $protocol_work = $protocol_work.$line['name']." (".$line["protocol_work"] .")  <br>";





#    echo "<tr style = 'background-color:".$sc."'>";
#    foreach ($column as $one) {
#        echo "<td>";
#        echo $line[$one];
#        echo "</td>";
#    }
#    echo "</tr>";
    }
if ($add_later_names != "" )
    $add_later_names = "Доназначения: ".$add_later_names ;

if ($test_start_after != "")
$test_start_after = "Поздний старт: ".$test_start_after;

if ($aliquot_work  != "")
$aliquot_work = "Долго делали: ".$aliquot_work;

if ($protocol_work  != "")
$protocol_work = "Ждали после готовности: ".$protocol_work;

#return implode("<br>",array_unique($c_protocol_number))."</td><td>".implode("<br>",array_unique($login_date))."</td>

return '<a href="gantt.php?id='.$c_protocol_number[0].'">'.$c_protocol_number[0]."</a></td><td>".implode("<br>",array_unique($login_date)).'</td>
<td style="background-color:'.$sample_mark.'">'.$sample_total."</td>
<td>".$add_later_names."</td><td>".$test_start_after."</td><td>".$aliquot_work."</td><td>".$protocol_work; #.depload() ;
#echo "</table>";
}




########################################



if (isset($_REQUEST['project'])) {
    $project = pg_escape_string($_REQUEST['project']);

$query = "select 
case when c_metodics.indicator_synonym is null then c_indicator.name1 else c_metodics.indicator_synonym end as name,
    t_analysis_method.full_name,
    row_number() OVER(order by result.name,sample.c_protocol_number) as nn,
case when sample.c_protocol_number like '%-21%' then sample.c_protocol_number else sample.c_protocol_number || '-21' end as c_protocol_number,
    sample.sample_name,
    result.protocol_value,
case when result.protocol_comment_unit is not null then 'в ' || (case when result.protocol_comment_value  is not null then (result.protocol_comment_value ||' ') else '' end) ||  u2.display_string else u1.display_string  end as protocol_unit,
    test.c_external_doc 
from result
inner join test on test.test_number = result.test_number
inner join sample on sample.sample_number = test.sample_number
inner join t_analysis_method on t_analysis_method.name = test.c_external_doc
inner join c_metodics on c_metodics.code = result.c_metodic_code
inner join c_indicator on c_indicator.name = c_metodics.indicator
left outer join units u1 on u1.unit_code =  result.protocol_unit
left outer join units u2 on u2.unit_code =  result.protocol_comment_unit

where sample.project ='".$project."' and result.c_metodic_code is not null


and test.status='A' and result.status='A' and sample.status='A'
order by test.lab,result.name,sample.c_protocol_number";

$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
echo "<a href='group.php'>Главный список</a>";
echo "<table>";
$olg_name = '';
while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
if ($old_name != $line['name'] ) {
echo "</table></br><table border='1'><tr>\n";
echo "<tr><th colspan='5'>".$line['name']."   ".$line['full_name']."</th></tr>";
foreach ($column as $key=>$one)
    echo "<th>".$key."</th>";
echo "</tr>";
$old_name = $line['name'];
}


$sc = "white";
if ($line["status"]=='A')
    $sc = "MediumSeaGreen";
if ($line["status"]=='X')
    $sc = "Dimgray";
if ($line["status"]=='N')
    $sc = "Tomato";

#----

echo "<tr style = 'background-color:".$sc."'>";
foreach ($column as $one) {

echo "<td>";
        echo $line[$one];
echo "</td>";
}

}

} else
{

$query_main = "select project.name,project.customer,project.date_created,project.created_by,project.status,
count(sample_number) as count_sample, row_number() OVER(order by name) as nn from sample
inner join project on project.name = sample.project
where closed ='F' and project.status not in ('X','P','U','I') and sample.parent_aliquot=0 and sample.status='A'
group by  project.name,project.customer,project.date_created,project.created_by,project.status
having count(sample_number) > 1
order by name
";


$result_main = pg_query($query_main) or die('Ошибка запроса: ' . pg_last_error());
echo "список открытых проектов где количество образцов >=2";


echo "<table border='1' id='protocol_table'>";
foreach ($column_main as $key=>$one)
    echo "<th>".$key."</th>";

while ($line = pg_fetch_array($result_main, null,  PGSQL_ASSOC)) {
$sc = "white";
if ($line["status"]=='V')
    $sc = "MediumSeaGreen";
if ($line["status"]=='X')
    $sc = "Dimgray";
if ($line["status"]=='N')
    $sc = "Tomato";

#----
echo "<tr style = 'background-color:".$sc."'>";
foreach ($column_main as $one) {

echo "<td>";
    if ($one=='name')
        echo '<a href="group.php?project='.$line[$one].'">'.$line[$one].'</a>';
    else
        echo $line[$one];
echo "</td>";
}

}



}
