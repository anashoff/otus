<head>
      <link rel="stylesheet" href="../css/table.css"> <!-- Путь к CSS файлу -->
<title>Список просроченных образцо за период</title>
</head>
<body>
<table border='1px'>
<tr>
<td><a href='/' class=button-style> Главная </td>
</tr>
</table>



<p>Здесь приведены ссылки на просроченные образцы по периодам</p>
<a href='2022-m01.php'  class=button-style>январь 2022</a>
