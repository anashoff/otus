<?php  #header('Content-Type: application/javascript');
$ids = $_REQUEST['id'];
preg_match('/\d*[-\d]*/', $ids, $matches);

$id = $matches[0];

if ($id!="") {

$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


$q = "select

sample.login_date::date as sample_login, 
sample.recd_date::date as sample_recd, sample.date_started as sample_started, 
sample.date_completed::date as sample_completed, sample.date_reviewed::date as sample_reviewed,

test.aliquot_group,test.analysis,test.reported_name,test.status,
test.date_started::date,test.date_completed::date,test.date_reviewed::date,test.t_date_enabled::date
from test 
inner join sample on sample.sample_number = test.sample_number
where c_protocol_number = '$id'
order by sample.sample_number,test.aliquot_group,test.analysis ";
#################################

function getreport($id,$num ) {
return "";
echo '
{ id: '.$num.', name: "Отчет", 
series: [ { name: "авторизация", start: "2021-04-01", end: "2021-04-15", color: "#f70" }, 
{ name: "Выпуск", start: "2021-04-01", end: "2021-04-01", color: "#f0f" }, 

] },';


}

########################################
$result = pg_query($q) or die('Ошибка запроса: ' . pg_last_error());

############################


echo 'var ganttData = [';
$i=0;
$old_aliq = "";
$old_aliq_end = "";
while ($line = pg_fetch_array($result, null,  PGSQL_ASSOC)) {
#заголовок

if ($old_aliq != $line['aliquot_group']) {
    if ($old_aliq != "") 
        echo '] }, ';
    $i+=1;
    $old_aliq = $line['aliquot_group'];

    echo '{ id: '.$i.', name: "'.$line['aliquot_group'].'", 
series: [ ';
    if (($line['sample_login']!= "") and ($line['sample_reviewed'] != ""))
        echo '{ name: "Аликвота всего", start: "'.$line['sample_login'].'", end: "'.$line['sample_reviewed'].'", color: "#0F0" }, 
';
    if (($line['sample_login']!= "") and ($line['sample_recd'] != ""))
        echo '{ name: "Аликвота получение", start: "'.$line['sample_login'].'", end: "'.$line['sample_recd'].'", color: "#000" }, 
';


    if (($line['sample_recd']!= "") and ($line['sample_completed'] != ""))
        echo '{ name: "Аликвота испытания", start: "'.$line['sample_recd'].'", end: "'.$line['sample_completed'].'", color: "#ff0" }, 
';


if (($line['sample_completed']!= "") and ($line['sample_reviewed'] != ""))
    echo '{ name: "Аликвота авторизация", start: "'.$line['sample_completed'].'", end: "'.$line['sample_reviewed'].'", color: "#F00" }, 
';


    }

#внутренние этапы
if (($line['date_reviewed']!= "") and ($line['t_date_enabled'] != "") and (!(empty($line['date_reviewed']))) and (!(empty($line['t_date_enabled'])))and (!(is_null($line['date_reviewed']))) and (!(is_null($line['t_date_enabled']))))
    echo '{ name: "'.$line['reported_name'].' Тест всего", start: "'.$line['t_date_enabled'].'", end: "'.$line['date_reviewed'].'", color: "#0ff" },
';

if (($line['date_started']!= "") and ($line['date_completed'] != ""))
# and (!(empty($line['date_reviewed']))) and (!(empty($line['t_date_enabled'])))and (!(is_null($line['date_reviewed']))) and (!(is_null($line['t_date_enabled']))))
    echo '{ name: "'.$line['reported_name'].' Тест работа", start: "'.$line['date_started'].'", end: "'.$line['date_completed'].'", color: "#06f" }, 
';



#конец одной диаграммы
if ($old_aliq_end != $line['aliquot_group']) {
    if ($old_aliq_end != $old_aliq) {
	$old_aliq_end = $old_aliq;
#        echo '] }, ';

    $old_aliq_end = $line['aliquot_group'];
    }
}
}


echo '] }, '; #конец последней серии

$i++;
getreport($id,$i);

echo ']; '; #конец json
############################





}

#for ($i = 1; $i <= 10; $i++) {

#echo '	{
#		id: '.$i.', name: "Этап '.$i.' '.$id.'", series: [
#			{ name: "Всего", start: new Date(2021,00,01), end: new Date(2021,00,10), color: "#0f0" },
#			{ name: "начало", start: new Date(2021,00,01), end: new Date(2021,00,03), color: "#00f" },
#			{ name: "середина", start: new Date(2021,00,04), end: new Date(2021,00,05), color: "#0f7" },
#			{ name: "конец", start: new Date(2021,00,05), end: new Date(2021,00,10), color: "#f00" }
#		]
#	},';
#
#}
#}

?>
