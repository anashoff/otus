<?php

#include "auth.php";
// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");


$column_main = [
    "№"=>"nn",
    "протокол"=>"c_protocol_number",
    "Дата регистрации"=>"login_date",
    "кто регистрировал"=>"login_by"

];




$query_main = "select c_protocol_number,login_date::date,login_by from sample where parent_aliquot = 0 and sample_number in
(select sample_number from sample_audit_log where table_name = 'SAMPLE' and user_name = 'KOSTERKIN_IM' 
and audit_type ='ReactivateSample' and sample_audit_log.audit_timestamp > '2022-01-01')";


$result_main = pg_query($query_main) or die('Ошибка запроса: ' . pg_last_error());
echo "реактивации за январь 2022";


echo "<table border='1' id='protocol_table'>";
foreach ($column_main as $key=>$one)
    echo "<th>".$key."</th>";

$nn = 0 ;

while ($line = pg_fetch_array($result_main, null,  PGSQL_ASSOC)) {
        $nn += 1;

$sc = "white";
if ($line["status"]=='V')
    $sc = "MediumSeaGreen";
if ($line["status"]=='X')
    $sc = "Dimgray";
if ($line["status"]=='N')
    $sc = "Tomato";

#----
echo "<tr style = 'background-color:".$sc."'>";
foreach ($column_main as $one) {

echo "<td>";
#    print_r($one);
#exit(0);
    if ($one == 'nn')
        echo $nn;
    if ($one=='name')
        echo '<a href="group.php?project='.$line[$one].'">'.$line[$one].'</a>';
    else
        echo $line[$one];
echo "</td>";
}

}




?>
