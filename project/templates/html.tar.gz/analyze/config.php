<?php
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());
?>
