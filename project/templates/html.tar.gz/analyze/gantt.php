<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html lang="ru">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="lib/jquery-ui-1.8.4.css" />
	<link rel="stylesheet" type="text/css" href="reset.css" />
	<link rel="stylesheet" type="text/css" href="jquery.ganttView.css" />
	<style type="text/css">
		body {
			font-family: tahoma, verdana, helvetica;
			font-size: 0.8em;
			padding: 10px;
		}
	</style>
	<title>Анализ образцов</title>
</head>


<body>
<?php 
$id = $_REQUEST['id'];
echo "<h1>Протокол $id<h1>"
?>



	<div id="ganttChart"></div>
	<br/><br/>
	<div id="eventMessage"></div>

	<script type="text/javascript" src="lib/jquery-1.4.2.js"></script>
	<script type="text/javascript" src="lib/date.js"></script>
	<script type="text/javascript" src="lib/jquery-ui-1.8.4.js"></script>
	<script type="text/javascript" src="jquery.ganttView.js"></script>
	<script type="text/javascript" src="data.php?id=<?php echo $id;?>"></script>
	<script type="text/javascript">
		$(function () {
			$("#ganttChart").ganttView({ 
				data: ganttData,
				slideWidth: 1000,
				behavior: {
					onClick: function (data) { 
						var msg = "You clicked on an event: { start: " + data.start.toString("M/d/yyyy") + ", end: " + data.end.toString("M/d/yyyy") + " }";
						$("#eventMessage").text(msg);
					//},
					//onResize: function (data) { 
					//	var msg = "You resized an event: { start: " + data.start.toString("M/d/yyyy") + ", end: " + data.end.toString("M/d/yyyy") + " }";
					//	$("#eventMessage").text(msg);
					//},
					//onDrag: function (data) { 
					//	var msg = "You dragged an event: { start: " + data.start.toString("M/d/yyyy") + ", end: " + data.end.toString("M/d/yyyy") + " }";
					//	$("#eventMessage").text(msg);
					}
				}
			});
			
			// $("#ganttChart").ganttView("setSlideWidth", 600);
		});
	</script>

</body>
</html>
