<?php


// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');

$days = '-28 day'; # количество дней на графике
function statstat($day) {
#статические данные по дням - общее количество протоколов
$l = [
"2020-07-13"=>"177",
"2020-07-14"=>"163",
"2020-07-15"=>"164",
"2020-07-16"=>"133",
"2020-07-17"=>"156",
"2020-07-18"=>"0",
"2020-07-19"=>"0",
"2020-07-20"=>"161",
"2020-07-21"=>"149",
"2020-07-22"=>"201",
"2020-07-23"=>"144",
"2020-07-24"=>"115",
"2020-07-25"=>"0",
"2020-07-26"=>"0",
"2020-07-27"=>"145",
"2020-07-28"=>"175",
"2020-07-29"=>"133",
"2020-07-30"=>"152",
"2020-07-31"=>"115",
"2020-08-03"=>"173",
"2020-08-04"=>"174",
"2020-08-05"=>"269",
"2020-08-06"=>"149",
"2020-08-07"=>"176",
"2020-08-10"=>"152",
"2020-08-11"=>"171",
"2020-08-12"=>"154",
"2020-08-13"=>"191",
"2020-08-14"=>"113",

"2020-08-17"=>"202",
"2020-08-18"=>"182",
"2020-08-19"=>"244",
"2020-08-20"=>"167",
"2020-08-21"=>"171",

"2020-08-24"=>"178",
"2020-08-25"=>"146",
"2020-08-26"=>"180",
"2020-08-27"=>"134",
"2020-08-28"=>"117",

"2020-08-31"=>"220",
"2020-09-01"=>"222",
"2020-09-02"=>"167",
"2020-09-03"=>"155",
"2020-09-04"=>"98",

"2020-09-07"=>"214",
"2020-09-08"=>"140",
"2020-09-09"=>"264",
"2020-09-10"=>"137",
"2020-09-11"=>"145",
"2020-09-12"=>"0",
"2020-09-13"=>"0",
"2020-09-14"=>"252",
"2020-09-15"=>"160",
"2020-09-16"=>"222",
"2020-09-17"=>"160",
"2020-09-18"=>"229",
"2020-09-19"=>"0",
"2020-09-20"=>"0",
"2020-09-21"=>"229",
"2020-09-22"=>"197",
"2020-09-23"=>"245",
"2020-09-24"=>"158",
"2020-09-25"=>"127",
"2020-09-26"=>"0",
"2020-09-27"=>"0",
"2020-09-28"=>"213",
"2020-09-29"=>"189",
"2020-09-30"=>"232",
"2020-10-01"=>"220",
"2020-10-02"=>"152",
"2020-10-03"=>"0",
"2020-10-04"=>"0",
"2020-10-05"=>"233",
];

$handle = fopen("total.csv", "r");
while (!feof($handle)) {
    $line = fgets($handle, 4096);
    $pieces = explode(";", $line);
    echo $buffer;
    $l[trim($pieces[0])] = trim($pieces[1]);
}
fclose($handle);
#print_r($l);





if (in_array ($day, array_keys($l)) )
    return $l[$day];
else
    return "0";
}








function getstat ( $day ) {
# динамические данные по дням
# протоколы в день,завершенные протоколы в день

$query= "select count(sample.c_protocol_number) as lims_count, 
(count(sample.c_protocol_number)  - SUM(CASE WHEN report_objects.report_number is null THEN 1 ELSE 0 END)) as protocol_count
--,sUM(CASE WHEN report_objects.report_number is null THEN 1 ELSE 0 END)*-1  
from sample
left join report_objects on object_id = sample_number
where sample.login_date::date ='".$day."'
and sample.status <> 'X'  and sample.parent_aliquot=0 --and report_objects.report_number is null
group by login_date::date
order by login_date::date" ;

#количество заявок в день
$q1 = "select count(distinct(sample.c_protocol_number))
from sample
left join report_objects on object_id = sample_number
inner join project on sample.project=project.name
where sample.login_date::date ='".$day."'
and sample.status <> 'X'  and sample.parent_aliquot=0 
and project.customer != 'TEST_EXAMPLE'

"; 
$r1 = pg_query($q1) or die('Ошибка запроса: ' . pg_last_error());
$arr1 = pg_fetch_array($r1 , null,  PGSQL_ASSOC);

#количество заявок без протоколов в день
$q2 = "select count(distinct(sample.c_protocol_number))
from sample
left join report_objects on object_id = sample_number
inner join project on sample.project=project.name
where sample.login_date::date ='".$day."'
and sample.status <> 'X'  and sample.parent_aliquot=0 
and report_objects.report_number is null
and project.customer != 'TEST_EXAMPLE'

"; 

$r2 = pg_query($q2) or die('Ошибка запроса: ' . pg_last_error());
$arr2 = pg_fetch_array($r2 , null,  PGSQL_ASSOC);

$q3= "select count(*) from reports where date_created::date ='".$day."'";
$r3 = pg_query($q3) or die('Ошибка запроса: ' . pg_last_error());
$arr3 = pg_fetch_array($r3 , null,  PGSQL_ASSOC);

return array($arr1['count'],$arr1['count']-$arr2['count'],$arr3['count']);

}



function getlogin($day,$name) {
#подсчет по методикам
#$q = " select count(sample.login_by)
#from result 
#inner join sample sa on result.sample_number=sa.sample_number
#inner join sample on sample.sample_number = sa.parent_aliquot
#inner join c_metodics on c_metodics.analysis=result.analysis and c_metodics.component=result.name
#inner join project on project.name=sample.project
#where sample.login_date::date = '".$day."' "; 

#if ($name != "OTHER") 
#    $q = $q +" and sample.login_by = '".$name."' ";
#else
#    $q = $q +" and sample.login_by not in ('ABROSIMOVA_OV','BOYARSKAYA_OV','BULGAKOVA_LE','KOROLEVA_SV','LEDNEVA_MN','TANTSEVA_SV','SHARAPOVA_GN') ";

#$q = $q + "and result.status <> 'X' and sample.status <> 'X'
#and project.customer!='TEST_EXAMPLE' and result.displayed='T'
#group by sample.login_by ";


#подсвет по СОПам
$q="select sample.login_by,count(sample.login_by)
from test
inner join sample sa on test.sample_number=sa.sample_number
inner join sample on sample.sample_number = sa.parent_aliquot
inner join project on project.name=sample.project
where sample.login_date::date = '".$day."' "; 
#"and sample.login_by = '".$name."'  
#echo $q;
if ($name != "OTHER") 
    $q = $q." and sample.login_by = '".$name."' ";
else
    $q = $q." and sample.login_by not in ('ABROSIMOVA_OV','BOYARSKAYA_OV','BULGAKOVA_LE','KOROLEVA_SV','LEDNEVA_MN','TANTSEVA_SV','SHARAPOVA_GN') ";

$q = $q." and project.status <> 'X'  and  test.status <> 'X'
and project.customer!='TEST_EXAMPLE'
group by sample.login_by ";

$r = pg_query($q) or die('Ошибка запроса: ' . pg_last_error());
$arr = pg_fetch_array($r , null,  PGSQL_ASSOC);
if ($arr['count'])
    return $arr['count'];
else
    return 0;
}

function getstatus($status) {
$q = "select count(sample.*) from sample 
inner join project on project.name=sample.project
where sample.parent_aliquot = 0 and sample.status = '".$status."' and sample.c_protocol_number is not null
and project.closed ='F' and project.date_created > now() - interval '30 day'
and project.customer!='TEST_EXAMPLE'
";

$r = pg_query($q) or die('Ошибка запроса: ' . pg_last_error());
$arr = pg_fetch_array($r , null,  PGSQL_ASSOC);
if ($arr['count'])
    return $arr['count'];
else
    return 0;
}



function pie($get) {
#подсчет неавторизованных образцов по дням
$q = "select (select count(d)-1 from generate_series( login_date::date , now()::date, '1 day'::interval ) as d where extract(dow from d) not in (0,6)  ) as dd, 
count ( (select count(d)-1 from generate_series( login_date::date , now()::date, '1 day'::interval ) as d where extract(dow from d) not in (0,6)  ) )  from sample 
inner join project on project.name=sample.project
where sample.status not in ('A','X') and parent_aliquot=0 
and project.closed ='F' and project.date_created > now() - interval '30 day'
and project.customer!='TEST_EXAMPLE'
group by dd";

$r = pg_query($q) or die('Ошибка запроса: ' . pg_last_error());

$ret = "";
$retarr = array();
while($arr = pg_fetch_array($r , null,  PGSQL_ASSOC) )   {
    $ret =$ret."{value: ".$arr['count'].", label: '".$arr['dd']." дн.' },";
    $retarr[] = $arr['dd'];
    }

if ($get=="list") 
    return $ret;
else
    return $retarr;
}

function pie2($day) {
#подсчет неавторизованных образцов по дням
$q = "select test.lab,count(test.lab)
from test
inner join sample sa on test.sample_number=sa.sample_number
inner join sample on sample.sample_number = sa.parent_aliquot
inner join project on project.name=sample.project
where sample.login_date::date > (now() - interval '30 day')::date and test.status not in ('X','A','R') 
and sample.login_date::date =  add_workdays(now()::date, -".$day.")::date
and project.customer!='TEST_EXAMPLE'
group by test.lab ;
";

$r = pg_query($q) or die('Ошибка запроса: ' . pg_last_error());

$ret = "";
while($arr = pg_fetch_array($r , null,  PGSQL_ASSOC) ) 
    $ret =$ret."{value: ".$arr['count'].", label: '".$arr['lab']."' },\n";

if ($ret == "")
    return " {value: 0, label: 'Пусто' }, ";
else
    return $ret;
}




#======================
# HTML
?>



<!doctype html>
<head>
  <script src="js/jquery.min.js"></script>
  <script src="js/raphael.min.js"></script>
  <script src="js/morris.js"></script>
  <script src="js/prettify.min.js"></script>
  <script src="lib/example.js"></script>
  <link rel="stylesheet" href="css/example.css">
  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/prettify/r224/prettify.min.css">
  <link rel="stylesheet" href="css/morris.css">

<script>
$(function () {
Morris.Bar({
  element: 'graph',
  data: [

<?php 
$end   = new DateTime( );
$begin  = new DateTime( );
$begin->modify($days);
for($i = $begin; $i <= $end; $i->modify('+1 day')){
#    echo "<p>".$i->format("Y-m-d")."</p>";
    $stat =  getstat($i->format("Y-m-d"));

    echo "{x: '".$i->format("Y-m-d")."', y: '".statstat($i->format("Y-m-d"))."', z: '".$stat[0]."', a: '".$stat[1]."',t: '".$stat[2]."'},\n";
} ?>
  ],
  xkey: 'x',
  ykeys: ['y', 'z', 'a','t'],
  barColors: ['#039', '#F30', '#093','#999'],
  labels: ['Всего', 'заявки ЛИМС', 'протоколы ЛИМС','Выпущено протоколов'],
  xLabelAngle: 90
}).on('click', function(i, row){
  console.log(i, row);
});

Morris.Bar({
  element: 'graph2',
  data: [

<?php 
$gpp = array("ABROSIMOVA_OV"=>"#ebbc7a",
"BOYARSKAYA_OV"=>"#F63100",
"BULGAKOVA_LE"=>"#2774A4",
"KOROLEVA_SV"=>"#6C59DC",
"LEDNEVA_MN"=>"#FC6EA3",
"TANTSEVA_SV"=>"#AC8C14",
"SHARAPOVA_GN"=>"#1A7C11",
"OTHER"=>"#B4B4B4",
);
$end   = new DateTime( );
$begin  = new DateTime( );
$begin->modify($days);
for($i = $begin; $i <= $end; $i->modify('+1 day')){
#    echo "<p>".$i->format("Y-m-d")."</p>";
    echo "{x: '".$i->format("Y-m-d")."',";

    foreach ($gpp as $name=>$color) {
    echo $name.": '".getlogin($i->format("Y-m-d"),$name)."',";
    }
    echo "},\n";
#    $stat =  getstat($i->format("Y-m-d"));

#    echo "{x: '".$i->format("Y-m-d")."', y: '".statstat($i->format("Y-m-d"))."', z: '".$stat[0]."', a: '".$stat[1]."',t: '".$stat[2]."'},\n";
} ?>
  ],
  xkey: 'x',
  ykeys: [
<?php
    foreach ($gpp as $name=>$color) 
echo "'",$name."',";
?>
],
  barColors: [
<?php
    foreach ($gpp as $name=>$color) 
echo "'".$color."',";
?>
],
  labels: [
<?php
    foreach ($gpp as $name=>$color) 
echo "'".$name."',";
?>

], xLabelAngle: 90
}).on('click', function(i, row){
  console.log(i, row);
});


Morris.Donut({
  element: 'pie',
  data: [
<?php echo pie("list"); ?>
  ],
colors: ['#0F0','#0c0','#090','#060','#030','#cc0','#fc0','#f90','#f30','#f00','#f00','#f00','#f00','#f00','#f00','#f00' ],
  formatter: function (x) { return x + " шт"}
}).on('click', function(i, row){
//alert(row.label.split(' ')[0]);
<?php

foreach (pie("arr") as $one) {

?>
    if (row.label.split(' ')[0]==<?php echo $one; ?>) {
    $('#pie2').html("");
    Morris.Donut({
      element: 'pie2',
      data: [
    <?php echo pie2($one); ?>
      ],  formatter: function (x) { return x + " шт"}
    });
    };

<?php


}

?>

  console.log(i, row);
});

//Morris.Donut({
// element: 'pie2',
//  data: [
<?php #echo pie2(); ?>
//  ],
//  formatter: function (x) { return x + " шт"}
//}).on('click', function(i, row){
//  console.log(i, row);
//});


 prettyPrint();
});
</script>










</head>
<body>
<h1>Заявки лаборатории</h1>
<table>
<tr><td>
<h3>Работа с заявками</h3>
<table border="1px">
<tr>
<th>U (не получены)</th>
<th>I (не начаты)</th>
<th>P (в работе)</th>
<th>C (завершены)</th>
<th>Всего</th>
</tr>
<tr>
<?php 
$su = getstatus('U');
$si = getstatus('I');
$sp = getstatus('P');
$sc = getstatus('C');

?>
<td><?php print($su); ?></td>
<td><?php print($si); ?></td>
<td><?php print($sp); ?></td>
<td><?php print($sc); ?></td>
<td><?php print($su+$si+$sp+$sc); ?></td>

</tr>
</table>

</td><td>
<h3>Продолжительность испытаний</h3>
<div id="pie"></div>
</td><td>
<h3>Долгие испытания испытания (>8 дней)</h3>
<table border="1px">
<tr>
<th>№ протокола</th>
<th>Дата заявки</th>
<th>Дата получения</th>
<th>Дней в работе</th>
</tr>

<?php 
$q_lost = "select sample.c_protocol_number,login_date,project.c_receipt_date,
(select count(d)-1 from generate_series ( login_date::date , now()::date, '1 day'::interval ) as d where extract(dow from d) not in (0,6)  ) as dd 
 from sample 
inner join project on project.name=sample.project
where sample.status not in ('A','X') and parent_aliquot=0 
and project.closed ='F' and project.date_created > now() - interval '30 day' 
and   (select count(d)-1 from generate_series ( login_date::date , now()::date, '1 day'::interval ) as d where extract(dow from d) not in (0,6)  ) >  8";
$r_lost = pg_query($q_lost) or die('Ошибка запроса: ' . pg_last_error());

while($arrl = pg_fetch_array($r_lost , null,  PGSQL_ASSOC) ) 
    echo "<tr><td><a href='http://192.168.50.250/queue/lims.php?read=".$arrl['c_protocol_number']."' target='_blank'> ".$arrl['c_protocol_number']."</a></td><td>".$arrl['login_date']."</td><td>".$arrl['c_receipt_date']."</td><td>".$arrl['dd']."</td></tr>";

?>
</table>
</td><td>
<h3>Неавторизованные тесты по подразделениям</h3>
<div id="pie2"></div>

</td><td>
<h3>Неавторизованные пробы подразделений</h3>
<div id="sample"></div>



</td></tr></table>




<div id="graph"></div>
<h1>Назначенные методики</h1>
<div id="graph2"></div>
<?php
 echo("php");
#getstat('2020-07-13');
#$end   = new DateTime( );
#$begin  = new DateTime( );
#$begin->modify('-30 day');
#for($i = $begin; $i <= $end; $i->modify('+1 day')){
#    echo "<p>".$i->format("Y-m-d")."</p>";
#}
#print_r(getstat('2020-08-06'));
echo "<br>";
#print_r(getlogin('2020-07-13','ABROSIMOVA_OV'));
#echo pie('dd');
#echo pie('count');
#print_r(pie("arr"));
#print_r(pie("arr"));


?>
</body>
