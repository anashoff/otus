  <head>
      <link rel="stylesheet" href="../css/table.css"> <!-- Путь к CSS файлу -->
  </head>

<?php

// Соединение, выбор базы данных
$dbconn = pg_connect("host=192.168.1.50 dbname=lims_full user=lims password=qq1qq2qq3")
    or die('Не удалось соединиться: ' . pg_last_error());

pg_set_client_encoding($dbconn, "UTF-8");
mb_internal_encoding('UTF-8');
setlocale(LC_ALL,"ru_RU.UTF-8");

$days = '-27 day';


function getstat() {
return "1";
}

function statstat() {
return "2";
}

function getlogin() {
return "3";
}

function pie() {
return "4";
}

function gethistory($date,$qlab,$qroom) {
$hquery = "select 0,
case when cc is null then 0 else cc end,
case when aa is null then 0 else aa end
from
(select sum(case when test.date_reviewed::date='".$date."' then 1 else 0 end) as aa,
sum(case when test.date_completed::date='".$date."' then 1 else 0 end) as cc
from test
inner join sample on sample.sample_number = test.sample_number
where (test.date_reviewed::date='".$date."' or test.date_completed::date='".$date."')".$qlab.$qroom." ) as summator";

#and test.lab = 'СОМИ'"

$result = pg_query($hquery) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($result, null, PGSQL_BOTH);
return $line;
#return [3,2,1];
}


function getavg($week,$qlab,$qroom) {
#скользящее среднее за x недель с учётом выходных
$hquery = "select count(test.test_number)/($week * 5)
from test
inner join sample on sample.sample_number = test.sample_number
where 
test.date_reviewed::date>=now() - interval '".$week." week' ".$qlab.$qroom." ";


$result = pg_query($hquery) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($result, null, PGSQL_BOTH);

return $line[0];
#return [3,2,1];
}

function getload($date,$qlab,$qroom) {

$hquery = "select count(test.test_number) from test
inner join sample on sample.sample_number = test.sample_number
inner join project on sample.project= project.name
where test.status != 'X' and sample.status != 'X' and project.customer != 'TEST_EXAMPLE'
and sample.login_date::date<='".$date."' and (test.date_reviewed::date>='".$date."' or test.date_reviewed is null) ".$qlab.$qroom." ";

$result = pg_query($hquery) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($result, null, PGSQL_BOTH);
return $line[0];
}


$query = "select name from lab where name not in ('ОБЩ','ГПП','СЕРОЛОГИЯ')";
$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
echo "<table border='1px'>\n";
echo "\t<tr>\n";
echo "<td><a href='.' class=button-style>Начало</td>";
echo "<td><a href='?lab=all' class=button-style>Всего</td>";


while ($line = pg_fetch_array($result, null,  PGSQL_NUM )) {

#    foreach ($line as $col_value) {
        echo "\t\t<td><a href='?lab=$line[0]' class=button-style>$line[0]</a></td>\n";
#    }
}
echo "<td><a href='?lab=СХРМИ&room=ХР-134' class=button-style>ХР-134</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-216' class=button-style>ХР-216</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-218' class=button-style>ХР-218</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-219' class=button-style>ХР-219</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-220' class=button-style>ХР-220</td>";
echo "<td><a href='?lab=СХРМИ&room=ХР-221' class=button-style>ХР-221</td>";
echo "<td><a href='/' class=button-style>Главная</td>";

    echo "\t</tr>\n";

echo "</table>\n";


// Очистка результата
pg_free_result($result);




$getlab = $_REQUEST['lab'];
if (isset( $_REQUEST['room']))
    $getroom = $_REQUEST['room'];
else
    $getroom = "";
#echo $lab;
preg_match ("/[a-zA-Zа-яА-Я]+/msiu",$getlab,$matches);
#print_r ($matches);
$lab = $matches[0];


preg_match ("/[a-zA-Zа-яА-Я-0-9]+/msiu",$getroom,$matches);
#print_r ($matches);
if (count($matches)>0)
    $room = $matches[0];
else
    $room = "";

if (strlen($room)>0) 
$qroom = " and sample.aliquot_group like '".$room."%' ";
else
$qroom="";


if (strlen($lab)>0) {
    if ($lab == "all") 
        $qlab = " and test.lab!='".$lab."' ";
    else
        $qlab = " and test.lab='".$lab."' ";
}
else
$qlab ="";





#exit(0);

if (strlen($lab)>0) {
$avg14 = getavg(14,$qlab,$qroom);
$avg4 = getavg(4,$qlab,$qroom);
$avg2 = getavg(2,$qlab,$qroom);



?>
<html>
<head>
 <meta http-equiv="refresh" content="300">
  <script src="/js/jquery.min.js"></script>
  <script src="/js/raphael.min.js"></script>
  <script src="/js/morris.js"></script>
  <script src="/js/prettify.min.js"></script>
  <script src="/js/example.js"></script>
  <link rel="stylesheet" href="css/example.css">
  <link rel="stylesheet" href="css/prettify.min.css">
  <link rel="stylesheet" href="css/morris.css">

<script>
$(function () {
Morris.Bar({
  element: 'graph',
  data: [

<?php
$end   = new DateTime( );
$begin  = new DateTime( );
$begin->modify($days);

echo "{x: 'ср. 14 нед.', t: '".$avg14."', c: '0',a: '0'},\n";
echo "{x: 'ср. 4 нед.', t: '".$avg4."', c: '0',a: '0'},\n";
echo "{x: 'ср. 2 нед.', t: '".$avg2."', c: '0',a: '0'},\n";



for($i = $begin; $i <= $end; $i->modify('+1 day')){
#    echo "<p>".$i->format("Y-m-d")."</p>";
    $hist =  gethistory($i->format("Y-m-d"),$qlab,$qroom);

    echo "{x: '".$i->format("Y-m-d")."', t: '".$hist[0]."', c: '".$hist[1]."',a: '".$hist[2]."'},\n";
} ?>
  ],
  xkey: 'x',
  ykeys: ['t', 'c','a'],
  barColors: ['#039', '#F30', '#093'],
  labels: ['Всего', 'Завершено', 'Авторизовано'],
  xLabelAngle: 90
}).on('click', function(i, row){
  console.log(i, row);
});

Morris.Bar({
  element: 'graph2',
  data: [

<?php
$gpp = array(
"1"=>"#bc7a",
);
$end   = new DateTime( );
$begin  = new DateTime( );
$begin->modify($days);

echo "{x: 'ср. 14 нед.', a: '0'},\n";
echo "{x: 'ср. 4 нед.', a: '0'},\n";
echo "{x: 'ср. 2 нед.', a: '0'},\n";


for($i = $begin; $i <= $end; $i->modify('+1 day')){
#    echo "<p>".$i->format("Y-m-d")."</p>";
    echo "{x: '".$i->format("Y-m-d")."', ";

#    foreach ($gpp as $name=>$color) {
    echo "y: '".getload($i->format("Y-m-d"),$qlab,$qroom)."',";
#    }
    echo "},\n";

} ?>
  ],
  xkey: 'x',
  ykeys: ['y'],
  barColors: ['#ff9900'],
  labels: [ 'Очередь' ], xLabelAngle: 90
}).on('click', function(i, row){
  console.log(i, row);
});


Morris.Donut({
  element: 'pie',
  data: [
<?php echo pie("list"); ?>
  ],
colors: ['#0F0','#0c0','#090','#060','#030','#cc0','#fc0','#f90','#f30','#f00','#f00','#f00','#f00','#f00','#f00','#f00' ],
  formatter: function (x) { return x + " шт"}
}).on('click', function(i, row){
//alert(row.label.split(' ')[0]);
<?php

foreach (pie("arr") as $one) {

?>
    if (row.label.split(' ')[0]==<?php echo $one; ?>) {
    $('#pie2').html("");
    Morris.Donut({
      element: 'pie2',
      data: [
    <?php echo pie2($one); ?>
      ],  formatter: function (x) { return x + " шт"}
    });
    };

<?php


}

?>

  console.log(i, row);
});

//Morris.Donut({
// element: 'pie2',
//  data: [
<?php #echo pie2(); ?>
//  ],
//  formatter: function (x) { return x + " шт"}
//}).on('click', function(i, row){
//  console.log(i, row);
//});


 prettyPrint();
});
</script>



</head>








<?php



#1
#echo "<table border='1px'>\n";
#echo "<tr><td  style='vertical-align:top'>\n";


##############################
#2
#####################################
#echo "<table style='border-spacing: 5px '>\n";
#echo "<tr><th colspan='4'>В процессе регистрации</th></tr>\n\n";

#echo "<tr><td>";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab'";
#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 


$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis),
    c_proj_approval.urgency as c_urgency
    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
    inner join c_proj_approval on c_proj_approval.project = project.name 

    where sample.status='U' 
    and test.lab='$lab' and test.analysis not like '%\_%'
    and project.customer <> 'TEST_EXAMPLE' ".$qroom."
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,c_proj_approval.urgency order by sample.text_id " ;
#    order by test.analysis,test.reported_name ";



#    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
#$total=0;
#echo "<table>\n";
#while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
#    echo "\t<tr><td>\n";
#    $total = $total + 1;
#    echo draw_sample($line,1);

#    echo "\t</td></tr>\n";
#}
#echo "<tr><td colspan='4'>Всего не получено $total</td></tr>";

#echo "</table>\n";


#echo "\n</td>";

###################### 

#echo "<td  style='vertical-align:top'>";
#echo "<table style='border-spacing: 5px '>";
#echo "<tr><th colspan='4'>Забрать в ГПП!!!</th></tr>";
#echo "<tr><td>";


#select storage_movement.*,project.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name,sample.*
#    from test
#    left outer join sample on test.sample_number=sample.sample_number
#    left outer join c_product on sample.c_product=c_product.id
#    left outer join project on sample.project = project.name
#    left outer join storage_movement on storage_movement.object_id = sample.sample_number
#	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
#    where test.status='I' and (sample.status='I' or sample.status='P')
#    and test.lab='СХРМИ' and test.analysis  not like '%\_%'
#    and project.customer <> 'TEST_EXAMPLE' 
#    order by test.analysis,test.reported_name








#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='I' and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name";
#$query = "select storage_movement.current_location,sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 

$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis), c_proj_approval.urgency as c_urgency
    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
    inner join c_proj_approval on c_proj_approval.project = project.name 

    where test.status='I' and (sample.status='I' or sample.status='P') and storage_movement.current_location = 175
    and test.lab='$lab' and test.analysis not like '%\_%'  
    and project.customer <> 'TEST_EXAMPLE' ".$qroom."
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,c_proj_approval.urgency order by sample.text_id " ;
#    order by test.analysis,test.reported_name ";

#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and test.status='I' and test.lab='$lab' order by test.analysis,test.reported_name";

#    $result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());

// Вывод результатов в HTML
#$total=0;
#echo "<table>\n";
#while ($line = pg_fetch_array($result, null, PGSQL_ASSOC)) {
#    echo "\t<tr><td>\n";
#    $total = $total + 1;
#    echo draw_sample($line,2);

#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
#    echo "\t</td></tr>\n";
#}
#echo "<tr><td colspan='4'>Всего не получено $total</td></tr>";
#echo "</table>\n";

#echo "</td>";




###########################


#echo "<td>";
#echo "<table>";

#echo "<td style='vertical-align:top'>";
#echo "<table style='border-spacing: 5px 'style='border-spacing: 5px '>\n";
#echo "<tr><th colspan='4'>В работе</th></tr>\n";

#    $query = "select test.analysis,test.reported_name from test,sample where test.sample_number=sample.sample_number and sample.status='P' and test.status='P' and test.lab='$lab' order by test.analysis,test.reported_name ";
#$query = "select sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name 
#    from test 
#    left outer join sample on test.sample_number=sample.sample_number 
#    left outer join c_product on sample.c_product=c_product.id 
#    left outer join project on sample.project = project.name
#
#    where sample.status='P' and test.status='P' 
#    and test.lab='$lab' and test.analysis not like '%\_%'  
#    and project.customer <> 'TEST_EXAMPLE'
#
#    order by test.analysis,test.reported_name ";


#$query = "select storage_location.description as stor,sample.c_protocol_number,sample.text_id,test.analysis,test.reported_name,c_product.name --
#string_agg(batch_objects.batch ,'<br>' order by test.analysis) as bo
$query="select storage_movement.current_location,sample.c_protocol_number,sample.text_id,c_product.name,string_agg(concat(test.analysis,': ',test.reported_name),'</br>' order by test.analysis),
(select string_agg(batch,'<br>') from batch_objects where batch_objects.sample_number = sample.sample_number) as bo, c_proj_approval.urgency as c_urgency

    from test 
    left outer join sample on test.sample_number=sample.sample_number 
    left outer join c_product on sample.c_product=c_product.id 
    left outer join project on sample.project = project.name
    left outer join storage_movement on storage_movement.object_id = sample.sample_number
	and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
    left outer join storage_location on storage_location.location_number=storage_movement.current_location
    inner join c_proj_approval on c_proj_approval.project = project.name 


    where ((test.status='I' and (sample.status='I' or sample.status='P')  and  storage_movement.current_location <> 175) or (sample.status='P' and test.status='P' ))
    and test.lab='$lab' and test.analysis not like '%\_%'  
    and project.customer <> 'TEST_EXAMPLE'  ".$qroom." 
group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,sample.sample_number, c_proj_approval.urgency order by sample.text_id";
#    order by test.analysis,test.reported_name ";
#    left outer join batch_objects on batch_objects.sample_number = sample.sample_number


$query = "select count(distinct(sample.sample_number)) as samples,
count(test.test_number) as tests,
sum(case when c_proj_approval.urgency = 'STD' then 1 else 0 end) as std,
sum(case when c_proj_approval.urgency = 'HIGH' then 1 else 0 end) as high
--sum(case when (c_proj_approval.urgency = 'STD' and  add_workdays(sample.login_date::date, 8)<=now()::date) then 1 else 0 end) as overstd --,
--sum(case when (c_proj_approval.urgency = 'HIGH' and  add_workdays(sample.login_date::date, 4)<=now()::date) then 1 else 0 end) as overhigh

---,test.analysis,c_proj_approval.urgency ,sample.*
    from test
    inner join sample on test.sample_number=sample.sample_number
   -- left outer join c_product on sample.c_product=c_product.id
    inner join project on sample.project = project.name
    --left outer join storage_movement on storage_movement.object_id = sample.sample_number
      --  and storage_movement.move_number=(select max(move_number) from storage_movement where storage_movement.object_id = sample.sample_number )
    inner join c_proj_approval on c_proj_approval.project = project.name
    where (sample.status not in ('A','X','R') and test.status not in ('A','R','X') ) 
    --and test.lab='$lab'
     and test.analysis not like '%\_%'
    and project.customer <> 'TEST_EXAMPLE' ".$qroom.$qlab." 
--group by sample.text_id,sample.c_protocol_number,storage_movement.current_location,c_product.name,sample.sample_number, c_proj_approval.urgency 
--order by sample.sample_number";

$now = date('H:i:s  d.m.Y');
if ($lab == "all")
    echo "<h2>Суммарная текущая загрузка [$now]</h2>";
else
    if ($room == "")
        echo "<h2>Текущая загрузка $lab [$now]</h2>";
    else
        echo "<h2>Текущая загрузка $room [$now]</h2>";



$result = pg_query($query) or die('Ошибка запроса: ' . pg_last_error());
$line = pg_fetch_array($result, null, PGSQL_ASSOC);
#print_r($line);
?>
<table border="1px" style="border-spacing: 5px">
<tr><th>Образцов в работе</th>
<th>Тестов в работе</th>
<th>Из них срочные</th>
</tr>
<tr>
<?php
echo "<td>".$line['samples']."</td>";
echo "<td>".$line['tests']."</td>";
echo "<td>".$line['high']."</td>";
#echo "<td>".round($line['tests']/$avg14,1)."</td><td> ".round($line['tests']/$avg4,1)."</td><td>".round($line['tests']/$avg2,1)."</td>";
echo "</tr></table>";
?>


<table border="1px" style="border-spacing: 5px">
<tr><th colspan="3">пакет заказов</th></tr>
<th>по среднему 14 недель</th>
<th>по среднему 4 недели</th>
<th>по среднему 2 недели</th>
</tr>
<tr>
<?php
echo "<td>".round($line['tests']/$avg14,1)."</td><td> ".round($line['tests']/$avg4,1)."</td><td>".round($line['tests']/$avg2,1)."</td>";
echo "</tr></table>";


#    echo "\t<tr><td>\n";
#    $total = $total + 1;
#    echo draw_sample($line,3);
#    foreach ($line as $col_value) {
#        echo "\t\t<td>$col_value</td>\n";
#    }
#    echo "\t</td></tr>\n";

#echo "<tr><td colspan='4'>Всего  в работе $total</td></tr>";

echo "</table>\n";

echo '<h3>Выполнение тестов'.$lab.' '.$room.'</h3>
<div id="graph" style="width:100%;height:300px"></div>
<h3>Размер очереди тестов '.$lab.' '.$room.'</h3>
<div id="graph2" style="width:100%;height:300px"></div>';


// Очистка результата
pg_free_result($result);
}
else {
?>

<h2>Текущая загрузка "Испытательной лаборатории "Тест-Пущино". Демонстрационная версия</h2><-- "-->
<p>Страница показывает загрузку подразделений лаборатории в настоящий момент времени</p>
<p>Внедрено:</p>
<ol>
<li> Загрузка подразделений и лаборатории на  момент просмотра</li>
<li> История завершения тестов за 14 дней. Среднее за 2, 4 и 14 недель. Для упрощения расчета среднего по рабочим дням</li>
<li> Синтетический расчет загрузки. Делим количество тестов на среднее количество авторизаций в день. получаем условные рабочие дни, необходимые для авторизации всех тестов</li>
</ol>



<p>В планах (если будет необходимость):</p>
<ol>
<li>История загрузки за 14 дней, среднее за: 2, 4 и 14 недель (в разработке)</li>
<li>Группировка загрузки по тестам</li>
<li>Расчет средней и пиковой пропускной способности подразделения по тестам</li>
<li>Что-то еще по запросу</li>
</ol>

<?php
}

echo  getenv('pg_connect');
 


// Закрытие соединения
pg_close($dbconn);
?>
</html>
